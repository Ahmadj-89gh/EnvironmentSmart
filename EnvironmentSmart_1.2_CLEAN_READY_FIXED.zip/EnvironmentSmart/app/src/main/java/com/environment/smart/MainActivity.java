package com.environment.smart;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 1001;
    private static final int PICK_MEDIA = 2001;
    private static final int GREEN = Color.rgb(11,61,46);
    private static final int GREEN2 = Color.rgb(20,120,78);
    private static final int LIGHT = Color.rgb(241,248,243);
    private static final int GOLD = Color.rgb(190,145,45);

    private final String[] TYPES = {"البلاغات البيئية","المهام الميدانية","المنشآت","التراخيص","النفايات"};
    private final String[] KEYS = {"complaints","tasks","facilities","licenses","waste"};
    private final String[] ICONS = {"!","+","■","▣","◆"};

    private LinearLayout root;
    private SharedPreferences prefs;
    private MapView map;
    private MyLocationNewOverlay locationOverlay;
    private final ArrayList<Marker> markers = new ArrayList<>();
    private boolean addMode;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private RecordItem mediaTarget;
    private TextView mediaLabel;

    private static final OnlineTileSourceBase SATELLITE = new OnlineTileSourceBase(
            "ArcGIS World Imagery",1,18,256,".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"},
            "Esri World Imagery") {
        @Override public String getTileURLString(long tile) {
            return getBaseUrl()+MapTileIndex.getZoom(tile)+"/"+MapTileIndex.getY(tile)+"/"+MapTileIndex.getX(tile)+mImageFilenameEnding;
        }
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(GREEN);
        getWindow().setNavigationBarColor(GREEN);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        prefs=getSharedPreferences("environment_smart_data",MODE_PRIVATE);
        showLogin();
    }

    private GradientDrawable bg(int color,float radius){
        GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); g.setStroke(1,Color.rgb(220,230,223)); return g;
    }
    private TextView text(String s,float size,int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); t.setPadding(16,10,16,10); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t;
    }
    private TextView action(String s){
        TextView t=text(s,15,GREEN); t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT_BOLD); t.setBackground(bg(LIGHT,18)); t.setPadding(8,8,8,8); t.setClickable(true); return t;
    }
    private void reset(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(12,10,12,10); root.setBackgroundColor(Color.WHITE); setContentView(root);
    }
    private ImageView logo(int size){
        ImageView i=new ImageView(this); i.setImageResource(R.drawable.app_icon); i.setScaleType(ImageView.ScaleType.CENTER_INSIDE); i.setContentDescription("شعار مديرية بيئة اللاذقية"); i.setPadding(3,3,3,3); i.setLayoutParams(new LinearLayout.LayoutParams(size,size)); return i;
    }
    private void header(){
        LinearLayout h=new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(8,4,8,4); h.setBackground(bg(LIGHT,20));
        LinearLayout words=new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL); words.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        TextView a=text("الجمهورية العربية السورية",14,GREEN); a.setTypeface(Typeface.DEFAULT_BOLD);
        TextView b=text("وزارة الإدارة المحلية والبيئة",14,GREEN); b.setTypeface(Typeface.DEFAULT_BOLD);
        TextView c=text("مديرية بيئة اللاذقية",14,GREEN); c.setTypeface(Typeface.DEFAULT_BOLD);
        words.addView(a); words.addView(b); words.addView(c);
        h.addView(words,new LinearLayout.LayoutParams(0,82,1)); h.addView(logo(72)); root.addView(h,new LinearLayout.LayoutParams(-1,92));
    }
    private void title(String s){
        TextView t=text(s,22,GREEN); t.setTypeface(Typeface.DEFAULT_BOLD); t.setGravity(Gravity.CENTER); t.setPadding(8,16,8,12); root.addView(t);
    }
    private void footer(){
        TextView t=text("تنفيذ الأستاذ أحمد جابر غصون  •  EnvironmentSmart 1.1",12,GREEN); t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.DEFAULT_BOLD); t.setBackground(bg(LIGHT,16)); root.addView(t,new LinearLayout.LayoutParams(-1,46));
    }

    private void showLogin(){
        reset(); header();
        LinearLayout spacer=new LinearLayout(this); spacer.setLayoutParams(new LinearLayout.LayoutParams(1,30)); root.addView(spacer);
        TextView name=text("نظام رقمي لإدارة أعمال مديرية البيئة",22,GREEN); name.setGravity(Gravity.CENTER); name.setTypeface(Typeface.DEFAULT_BOLD); root.addView(name,new LinearLayout.LayoutParams(-1,70));
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(20,18,20,18); card.setBackground(bg(LIGHT,24));
        EditText user=new EditText(this); user.setHint("اسم المستخدم"); user.setSingleLine(true); user.setTextDirection(View.TEXT_DIRECTION_RTL);
        EditText pass=new EditText(this); pass.setHint("كلمة المرور"); pass.setSingleLine(true); pass.setInputType(0x81); pass.setTextDirection(View.TEXT_DIRECTION_RTL);
        TextView login=action("دخول"); login.setTextColor(Color.WHITE); login.setBackground(bg(GREEN2,22)); login.setTextSize(17);
        card.addView(user,new LinearLayout.LayoutParams(-1,58)); card.addView(pass,new LinearLayout.LayoutParams(-1,58)); card.addView(login,new LinearLayout.LayoutParams(-1,56));
        root.addView(card,new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView hint=text("نسخة أولية تجريبية\nاسم المستخدم: admin   |   كلمة المرور: admin123",13,Color.DKGRAY); hint.setGravity(Gravity.CENTER); root.addView(hint,new LinearLayout.LayoutParams(-1,80));
        footer();
        login.setOnClickListener(v->{String u=user.getText().toString().trim(),p=pass.getText().toString(); if((u.equals("admin")&&p.equals("admin123"))||(u.equals("أحمد")&&p.equals("1234"))) showDashboard(); else Toast.makeText(this,"بيانات الدخول التجريبية: admin / admin123",Toast.LENGTH_LONG).show();});
    }

    private void showDashboard(){
        reset(); header(); title("لوحة أعمال مديرية البيئة");
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        addMenu(list,"01  الخريطة البيئية","طرق + أقمار صناعية + تضاريس + GPS + حفظ المواقع",v->showMap());
        addMenu(list,"02  البلاغات البيئية","إضافة وتعديل وحذف ومتابعة وتقييم وإرفاق صورة/فيديو",v->showRecords(0));
        addMenu(list,"03  المهام الميدانية","إدارة المهام والزيارات والتفتيش مع المرفقات",v->showRecords(1));
        addMenu(list,"04  المنشآت","ملف المنشأة والحالة والتقييم والمرفقات",v->showRecords(2));
        addMenu(list,"05  التراخيص","التراخيص والموافقات والحالة والمرفقات",v->showRecords(3));
        addMenu(list,"06  النفايات","المواقع والكميات والحالة والتقييم والمرفقات",v->showRecords(4));
        addMenu(list,"07  التقارير والإحصائيات","إجمالي السجلات ومتوسط التقييم",v->showReports());
        addMenu(list,"08  معلومات التطبيق","EnvironmentSmart 1.1",v->message("البيئة الذكية","نظام رقمي لإدارة أعمال مديرية بيئة اللاذقية."));
        TextView out=action("تسجيل الخروج"); out.setTextColor(Color.WHITE); out.setBackground(bg(GREEN,18)); list.addView(out,new LinearLayout.LayoutParams(-1,54)); out.setOnClickListener(v->showLogin());
        footer();
    }
    private void addMenu(LinearLayout parent,String title,String sub,View.OnClickListener click){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(14,10,14,10); c.setBackground(bg(LIGHT,20));
        TextView a=text(title,18,GREEN); a.setTypeface(Typeface.DEFAULT_BOLD); a.setGravity(Gravity.RIGHT); TextView b=text(sub,13,Color.DKGRAY); b.setGravity(Gravity.RIGHT);
        c.addView(a); c.addView(b); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,82); lp.setMargins(0,6,0,6); parent.addView(c,lp); c.setOnClickListener(click);
    }

    private void showRecords(int type){
        reset(); header(); title(ICONS[type]+"  "+TYPES[type]);
        TextView info=text("إضافة / تعديل / حذف / تقييم من 0 إلى 5 / مرفق صورة أو فيديو",13,GREEN); info.setGravity(Gravity.CENTER); root.addView(info,new LinearLayout.LayoutParams(-1,48));
        TextView add=action("+  إضافة سجل جديد"); add.setTextColor(Color.WHITE); add.setBackground(bg(GREEN2,18)); root.addView(add,new LinearLayout.LayoutParams(-1,54));
        ScrollView scroll=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        add.setOnClickListener(v->recordDialog(type,null,()->render(type,list))); render(type,list); footer();
    }
    private void render(int type,LinearLayout list){
        list.removeAllViews(); List<RecordItem> records=load(KEYS[type]);
        if(records.isEmpty()){TextView empty=text("لا توجد سجلات بعد.\nاضغط «إضافة سجل جديد». ",16,Color.DKGRAY); empty.setGravity(Gravity.CENTER); list.addView(empty,new LinearLayout.LayoutParams(-1,120)); return;}
        for(RecordItem r:records){
            LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(12,10,12,10); c.setBackground(bg(LIGHT,18));
            TextView h=text(r.name,18,GREEN); h.setTypeface(Typeface.DEFAULT_BOLD); c.addView(h);
            c.addView(text("التقييم: "+stars(r.rating)+"    الحالة: "+r.status,13,Color.DKGRAY));
            if(!r.details.isEmpty()) c.addView(text(r.details,13,Color.DKGRAY));
            if(!r.attachment.isEmpty()) c.addView(text("مرفق: "+fileName(Uri.parse(r.attachment)),12,GREEN));
            c.addView(text(r.date,11,Color.GRAY));
            LinearLayout actions=new LinearLayout(this); TextView edit=action("تعديل"), del=action("حذف"); actions.addView(edit,new LinearLayout.LayoutParams(0,48,1)); actions.addView(del,new LinearLayout.LayoutParams(0,48,1)); c.addView(actions);
            edit.setOnClickListener(v->recordDialog(type,r,()->render(type,list)));
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف السجل").setMessage("هل تريد حذف هذا السجل؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{delete(KEYS[type],r.id);render(type,list);}).show());
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT); lp.setMargins(0,6,0,6); list.addView(c,lp);
        }
    }
    private String stars(float rating){int n=Math.round(rating);StringBuilder s=new StringBuilder();for(int i=1;i<=5;i++)s.append(i<=n?"★":"☆");return s.toString()+"  "+String.format(Locale.US,"%.1f / 5",rating);}

    private void recordDialog(int type,RecordItem existing,Runnable refresh){
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(8,0,8,0);
        EditText name=new EditText(this); name.setHint("الاسم / العنوان"); name.setSingleLine(true);
        EditText details=new EditText(this); details.setHint("الوصف / الملاحظات"); details.setMinLines(3);
        EditText status=new EditText(this); status.setHint("الحالة"); status.setSingleLine(true);
        RatingBar rating=new RatingBar(this,null,android.R.attr.ratingBarStyleSmall); rating.setNumStars(5); rating.setStepSize(0.5f);
        TextView attach=action("إرفاق صورة أو فيديو"); attach.setTextColor(GREEN);
        mediaLabel=text("لا يوجد مرفق",12,Color.GRAY); mediaLabel.setGravity(Gravity.CENTER);
        form.addView(name); form.addView(details); form.addView(status); form.addView(rating,new LinearLayout.LayoutParams(-1,55)); form.addView(attach,new LinearLayout.LayoutParams(-1,50)); form.addView(mediaLabel,new LinearLayout.LayoutParams(-1,42));
        final String[] attachment={existing==null?"":existing.attachment};
        if(existing!=null){name.setText(existing.name);details.setText(existing.details);status.setText(existing.status);rating.setRating(existing.rating);if(!existing.attachment.isEmpty())mediaLabel.setText("مرفق: "+fileName(Uri.parse(existing.attachment)));}
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(existing==null?"إضافة سجل":"تعديل السجل").setView(form).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",null).create();
        attach.setOnClickListener(v->{mediaTarget=existing; final String[] holder=attachment; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"}); mediaPending=holder; startActivityForResult(i,PICK_MEDIA);});
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("أدخل الاسم");return;}RecordItem r=existing==null?new RecordItem():existing;if(r.id==null||r.id.isEmpty())r.id=UUID.randomUUID().toString();r.name=n;r.details=details.getText().toString().trim();r.status=status.getText().toString().trim();if(r.status.isEmpty())r.status="جديد";r.rating=rating.getRating();r.attachment=attachment[0];r.date=new SimpleDateFormat("yyyy/MM/dd HH:mm",Locale.getDefault()).format(new Date());save(KEYS[type],r);dlg.dismiss();refresh.run();}));
        dlg.show();
    }
    private String[] mediaPending={""};
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==PICK_MEDIA&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();mediaPending[0]=u.toString();if(mediaLabel!=null)mediaLabel.setText("مرفق: "+fileName(u));try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}}
    private String fileName(Uri u){try{android.database.Cursor c=getContentResolver().query(u,null,null,null,null);if(c!=null){int ix=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(c.moveToFirst()&&ix>=0){String n=c.getString(ix);c.close();return n;}c.close();}}catch(Exception ignored){}return "ملف مرفق";}

    private static class RecordItem{String id="",name="",details="",status="جديد",date="",attachment="";float rating=0;}
    private String enc(String s){return android.util.Base64.encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);}
    private String dec(String s){try{return new String(android.util.Base64.decode(s,android.util.Base64.NO_WRAP),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    private String pack(RecordItem r){return enc(r.id)+"|"+enc(r.name)+"|"+enc(r.details)+"|"+enc(r.status)+"|"+r.rating+"|"+enc(r.date)+"|"+enc(r.attachment);}
    private RecordItem unpack(String x){String[] p=x.split("\\|",-1);if(p.length<7)return null;try{RecordItem r=new RecordItem();r.id=dec(p[0]);r.name=dec(p[1]);r.details=dec(p[2]);r.status=dec(p[3]);r.rating=Float.parseFloat(p[4]);r.date=dec(p[5]);r.attachment=dec(p[6]);return r;}catch(Exception e){return null;}}
    private List<RecordItem> load(String key){List<RecordItem> out=new ArrayList<>();Set<String>s=prefs.getStringSet(key,new HashSet<>());for(String x:s){RecordItem r=unpack(x);if(r!=null)out.add(r);}return out;}
    private void save(String key,RecordItem item){List<RecordItem> all=load(key);boolean rep=false;for(int i=0;i<all.size();i++)if(all.get(i).id.equals(item.id)){all.set(i,item);rep=true;break;}if(!rep)all.add(item);Set<String>s=new HashSet<>();for(RecordItem r:all)s.add(pack(r));prefs.edit().putStringSet(key,s).apply();}
    private void delete(String key,String id){Set<String>s=prefs.getStringSet(key,new HashSet<>());Set<String> n=new HashSet<>();for(String x:s){RecordItem r=unpack(x);if(r!=null&&!r.id.equals(id))n.add(x);}prefs.edit().putStringSet(key,n).apply();}

    private void showReports(){
        reset();header();title("التقارير والإحصائيات");
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);scroll.addView(box);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        int total=0;double sum=0;StringBuilder s=new StringBuilder();s.append("ملخص أعمال مديرية البيئة\n\n");for(int i=0;i<TYPES.length;i++){List<RecordItem> rs=load(KEYS[i]);double x=0;for(RecordItem r:rs)x+=r.rating;total+=rs.size();sum+=x;s.append(TYPES[i]).append(": ").append(rs.size()).append(" سجل\n");}double avg=total==0?0:sum/total;s.append("\nإجمالي السجلات: ").append(total).append("\nمتوسط التقييم: ").append(String.format(Locale.US,"%.2f / 5",avg));TextView r=text(s.toString(),18,GREEN);r.setBackground(bg(LIGHT,22));r.setPadding(18,24,18,24);box.addView(r);TextView back=action("العودة إلى الرئيسية");box.addView(back,new LinearLayout.LayoutParams(-1,54));back.setOnClickListener(v->showDashboard());footer();
    }

    private void showMap(){
        Configuration.getInstance().load(this,getSharedPreferences("osmdroid",MODE_PRIVATE));reset();header();title("الخريطة البيئية");
        LinearLayout layers=new LinearLayout(this);layers.setOrientation(LinearLayout.HORIZONTAL);TextView roads=action("الطرق"),sat=action("الأقمار"),terrain=action("التضاريس");layers.addView(roads,new LinearLayout.LayoutParams(0,54,1));layers.addView(sat,new LinearLayout.LayoutParams(0,54,1));layers.addView(terrain,new LinearLayout.LayoutParams(0,54,1));root.addView(layers);
        LinearLayout acts=new LinearLayout(this);acts.setOrientation(LinearLayout.HORIZONTAL);TextView gps=action("GPS"),add=action("إضافة"),search=action("بحث"),saved=action("المحفوظة");acts.addView(gps,new LinearLayout.LayoutParams(0,54,1));acts.addView(add,new LinearLayout.LayoutParams(0,54,1));acts.addView(search,new LinearLayout.LayoutParams(0,54,1));acts.addView(saved,new LinearLayout.LayoutParams(0,54,1));root.addView(acts);
        map=new MapView(this);map.setTileSource(TileSourceFactory.MAPNIK);map.setMultiTouchControls(true);map.setBuiltInZoomControls(true);map.setMinZoomLevel(5);map.setMaxZoomLevel(18);map.getController().setCenter(new GeoPoint(34.8021,38.9968));map.getController().setZoom(7);root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        TextView back=action("العودة إلى الرئيسية");root.addView(back,new LinearLayout.LayoutParams(-1,52));footer();
        loadMarkers();setupLocation();installMapEvents();
        roads.setOnClickListener(v->{map.setTileSource(TileSourceFactory.MAPNIK);map.invalidate();});sat.setOnClickListener(v->{map.setTileSource(SATELLITE);map.invalidate();});terrain.setOnClickListener(v->{map.setTileSource(TileSourceFactory.OpenTopo);map.invalidate();});
        gps.setOnClickListener(v->{if(locationOverlay!=null&&locationOverlay.getMyLocation()!=null){map.getController().animateTo(locationOverlay.getMyLocation());map.getController().setZoom(15);}else{requestLocation();Toast.makeText(this,"جارٍ تحديد الموقع...",Toast.LENGTH_SHORT).show();}});
        add.setOnClickListener(v->{addMode=true;Toast.makeText(this,"اضغط مطولًا على الخريطة لحفظ الموقع",Toast.LENGTH_LONG).show();});search.setOnClickListener(v->searchLocation());saved.setOnClickListener(v->showSaved());back.setOnClickListener(v->showDashboard());
    }
    private void installMapEvents(){map.getOverlays().add(new MapEventsOverlay(new MapEventsReceiver(){public boolean singleTapConfirmedHelper(GeoPoint p){return false;}public boolean longPressHelper(GeoPoint p){if(!addMode)return false;addMode=false;askPlace(p);return true;}}));}
    private void askPlace(GeoPoint p){EditText e=new EditText(this);e.setHint("اسم الموقع");new AlertDialog.Builder(this).setTitle("حفظ موقع").setView(e).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->saveMarker(e.getText().toString().trim().isEmpty()?"موقع بيئي":e.getText().toString().trim(),p)).show();}
    private void saveMarker(String name,GeoPoint p){Marker m=new Marker(map);m.setPosition(p);m.setTitle(name);m.setSnippet(String.format(Locale.US,"%.6f, %.6f",p.getLatitude(),p.getLongitude()));m.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM);m.setOnMarkerClickListener((a,b)->markerDialog(a));map.getOverlays().add(m);markers.add(m);persistMarkers();map.invalidate();}
    private void markerDialog(Marker m){new AlertDialog.Builder(this).setTitle(m.getTitle()).setMessage("الإحداثيات: "+m.getSnippet()).setPositiveButton("تعديل",(d,w)->{EditText e=new EditText(this);e.setText(m.getTitle());new AlertDialog.Builder(this).setTitle("تعديل الموقع").setView(e).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d2,w2)->{if(!e.getText().toString().trim().isEmpty())m.setTitle(e.getText().toString().trim());persistMarkers();}).show();}).setNegativeButton("حذف",(d,w)->{map.getOverlays().remove(m);markers.remove(m);persistMarkers();map.invalidate();}).setNeutralButton("إغلاق",null).show();}
    private void persistMarkers(){Set<String>s=new HashSet<>();for(Marker m:markers){GeoPoint p=m.getPosition();s.add(enc(m.getTitle())+"|"+p.getLatitude()+"|"+p.getLongitude());}prefs.edit().putStringSet("places",s).apply();}
    private void loadMarkers(){Set<String>s=prefs.getStringSet("places",new HashSet<>());for(String x:s){String[]p=x.split("\\|",-1);if(p.length!=3)continue;try{saveMarkerSilent(dec(p[0]),new GeoPoint(Double.parseDouble(p[1]),Double.parseDouble(p[2])));}catch(Exception ignored){}}}
    private void saveMarkerSilent(String name,GeoPoint p){Marker m=new Marker(map);m.setPosition(p);m.setTitle(name);m.setSnippet(String.format(Locale.US,"%.6f, %.6f",p.getLatitude(),p.getLongitude()));m.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM);m.setOnMarkerClickListener((a,b)->markerDialog(a));map.getOverlays().add(m);markers.add(m);}
    private void showSaved(){if(markers.isEmpty()){message("المواقع المحفوظة","لا توجد مواقع محفوظة.");return;}String[] n=new String[markers.size()];for(int i=0;i<markers.size();i++)n[i]=markers.get(i).getTitle();new AlertDialog.Builder(this).setTitle("المواقع المحفوظة").setItems(n,(d,w)->{Marker m=markers.get(w);map.getController().animateTo(m.getPosition());map.getController().setZoom(15);m.showInfoWindow();}).setNegativeButton("إغلاق",null).show();}
    private void searchLocation(){EditText e=new EditText(this);e.setHint("اللاذقية أو حلب");new AlertDialog.Builder(this).setTitle("بحث عن موقع").setView(e).setNegativeButton("إلغاء",null).setPositiveButton("بحث",(d,w)->{String q=e.getText().toString().trim();if(q.isEmpty())return;executor.execute(()->{try{android.location.Geocoder g=new android.location.Geocoder(this,Locale.getDefault());List<android.location.Address> r=g.getFromLocationName(q,5,32.3,35.6,37.4,42.5);runOnUiThread(()->{if(r==null||r.isEmpty()){Toast.makeText(this,"لم يتم العثور على الموقع",Toast.LENGTH_LONG).show();return;}GeoPoint p=new GeoPoint(r.get(0).getLatitude(),r.get(0).getLongitude());map.getController().animateTo(p);map.getController().setZoom(13);});}catch(Exception ex){runOnUiThread(()->Toast.makeText(this,"البحث يحتاج اتصالًا بالإنترنت",Toast.LENGTH_LONG).show());}});}).show();}
    private void setupLocation(){locationOverlay=new MyLocationNewOverlay(new GpsMyLocationProvider(this),map);locationOverlay.enableMyLocation();map.getOverlays().add(locationOverlay);if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED)locationOverlay.enableFollowLocation();else requestLocation();}
    private void requestLocation(){if(android.os.Build.VERSION.SDK_INT>=23)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==LOCATION_REQUEST&&locationOverlay!=null&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED){locationOverlay.enableMyLocation();locationOverlay.enableFollowLocation();}}
    private void message(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("حسنًا",null).show();}
    @Override protected void onResume(){super.onResume();if(map!=null)map.onResume();}
    @Override protected void onPause(){if(map!=null)map.onPause();super.onPause();}
    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
}
