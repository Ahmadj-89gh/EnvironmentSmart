package com.environment.smart;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 1001;
    private static final int GREEN = Color.rgb(11, 61, 46);
    private static final int GREEN2 = Color.rgb(17, 111, 73);
    private static final int GOLD = Color.rgb(190, 145, 45);
    private static final int CREAM = Color.rgb(247, 250, 247);
    private static final String[] TYPES = {"البلاغات", "المهام الميدانية", "المنشآت", "التراخيص", "النفايات"};
    private static final String[] TYPE_KEYS = {"complaints", "tasks", "facilities", "licenses", "waste"};
    private static final String[] TYPE_ICONS = {"🚨", "👷", "🏭", "📄", "🗑️"};

    private LinearLayout root, content;
    private DrawerLayout drawerLayout;
    private MapView map;
    private MyLocationNewOverlay myLocationOverlay;
    private SharedPreferences prefs;
    private final ArrayList<Marker> savedMarkers = new ArrayList<>();
    private boolean addMode = false;
    private final ExecutorService searchExecutor = Executors.newSingleThreadExecutor();

    private static final OnlineTileSourceBase SATELLITE = new OnlineTileSourceBase(
            "ArcGIS World Imagery", 1, 18, 256, ".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"},
            "Esri World Imagery") {
        @Override public String getTileURLString(final long tile) {
            return getBaseUrl() + MapTileIndex.getZoom(tile) + "/" + MapTileIndex.getY(tile) + "/" + MapTileIndex.getX(tile) + mImageFilenameEnding;
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        prefs = getSharedPreferences("environment_smart_data", MODE_PRIVATE);
        showLogin();
    }

    private TextView tv(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(18, 12, 18, 12); t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button btn(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(15); b.setAllCaps(false); b.setMinHeight(50);
        return b;
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); return g;
    }

    private void base() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(14, 12, 14, 12);
        root.setBackgroundColor(Color.WHITE); setContentView(root);
    }

    private ImageView logo(int size) {
        ImageView image = new ImageView(this); image.setImageResource(R.drawable.app_icon); image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setPadding(4,4,4,4); image.setContentDescription("شعار مديرية بيئة اللاذقية");
        image.setLayoutParams(new LinearLayout.LayoutParams(size, size)); return image;
    }

    private LinearLayout brandBlock(boolean compact) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(8,8,8,8);
        box.setBackground(bg(CREAM, 24));
        box.addView(logo(compact ? 70 : 104));
        TextView gov = tv("الجمهورية العربية السورية\nوزارة الإدارة المحلية والبيئة\nمديرية بيئة اللاذقية", compact ? 12 : 14);
        gov.setTextColor(GREEN); gov.setTypeface(Typeface.DEFAULT_BOLD); box.addView(gov);
        TextView name = tv("🌿 EnvironmentSmart\nخريطة سورية البيئية الذكية", compact ? 15 : 18);
        name.setTextColor(GREEN); name.setTypeface(Typeface.DEFAULT_BOLD); box.addView(name);
        return box;
    }

    private void addCreditFooter() {
        TextView f = tv("تنفيذ الأستاذ أحمد جابر غصون", 12); f.setTextColor(GREEN); f.setTypeface(Typeface.DEFAULT_BOLD);
        f.setBackground(bg(CREAM, 18)); root.addView(f, new LinearLayout.LayoutParams(-1, 48));
    }

    private void addTopBar(String title, boolean menu) {
        LinearLayout bar = new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(4,2,4,2);
        if (menu) {
            Button m = btn("☰"); m.setTextSize(24); m.setTextColor(GREEN); m.setBackgroundColor(Color.TRANSPARENT);
            bar.addView(m, new LinearLayout.LayoutParams(58,58)); m.setOnClickListener(v -> drawerLayout.openDrawer(Gravity.RIGHT));
        }
        TextView titleView = tv(title, 18); titleView.setTextColor(GREEN); titleView.setTypeface(Typeface.DEFAULT_BOLD); titleView.setGravity(Gravity.CENTER);
        bar.addView(titleView, new LinearLayout.LayoutParams(0,58,1));
        if (menu) bar.addView(logo(52));
        root.addView(bar);
    }

    private void showLogin() {
        base();
        ScrollView scroll = new ScrollView(this); LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(page); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        page.addView(brandBlock(false), new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        Space s = new Space(this); page.addView(s, new LinearLayout.LayoutParams(1,14));
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(22,18,22,18); card.setBackground(bg(Color.WHITE,28));
        TextView title = tv("تسجيل الدخول", 23); title.setTextColor(GREEN); title.setTypeface(Typeface.DEFAULT_BOLD); card.addView(title);
        EditText u = new EditText(this); u.setHint("اسم المستخدم"); u.setSingleLine(true); u.setInputType(InputType.TYPE_CLASS_TEXT); card.addView(u, new LinearLayout.LayoutParams(-1,58));
        EditText p = new EditText(this); p.setHint("كلمة المرور"); p.setSingleLine(true); p.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD); card.addView(p, new LinearLayout.LayoutParams(-1,58));
        Button login = btn("دخول"); login.setTextColor(Color.WHITE); login.setTextSize(17); login.setBackground(bg(GREEN2,40)); card.addView(login, new LinearLayout.LayoutParams(-1,58));
        TextView register = tv("إنشاء حساب جديد", 13); register.setTextColor(GREEN2); register.setTypeface(Typeface.DEFAULT_BOLD); card.addView(register);
        page.addView(card, new LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        page.addView(tv("نسخة EnvironmentSmart 1.1", 12));
        page.addView(tv("تنفيذ الأستاذ أحمد جابر غصون", 12));
        login.setOnClickListener(v -> {
            boolean ok = (u.getText().toString().trim().equals("admin") && p.getText().toString().equals("admin123")) ||
                    (u.getText().toString().trim().equals("أحمد") && p.getText().toString().equals("1234"));
            if (ok) showDashboard(); else Toast.makeText(this,"بيانات الدخول التجريبية: admin / admin123",Toast.LENGTH_LONG).show();
        });
    }

    private void setupDrawer() {
        drawerLayout = new DrawerLayout(this);
        drawerLayout.setBackgroundColor(Color.WHITE);
        // Move the current screen into the drawer layout.
        root.removeAllViews();
        LinearLayout mainPanel = new LinearLayout(this); mainPanel.setOrientation(LinearLayout.VERTICAL); mainPanel.setBackgroundColor(Color.WHITE);
        root = mainPanel;
        drawerLayout.addView(mainPanel, new DrawerLayout.LayoutParams(-1,-1));
        LinearLayout drawer = new LinearLayout(this); drawer.setOrientation(LinearLayout.VERTICAL); drawer.setPadding(14,20,14,14); drawer.setGravity(Gravity.TOP); drawer.setBackgroundColor(Color.WHITE);
        DrawerLayout.LayoutParams dp = new DrawerLayout.LayoutParams((int)(getResources().getDisplayMetrics().widthPixels*0.82f),-1); dp.gravity = Gravity.RIGHT;
        drawerLayout.addView(drawer, dp);
        setContentView(drawerLayout);
        drawer.addView(brandBlock(true));
        drawer.addView(tv("القائمة الرئيسية",20), new LinearLayout.LayoutParams(-1,58));
        String[] menu = {"🏠 الرئيسية","🗺️ الخريطة","🚨 البلاغات","👷 المهام الميدانية","🏭 المنشآت","📄 التراخيص","🗑️ النفايات","📊 التقارير والإحصائيات","⚙️ الإعدادات","ℹ️ معلومات التطبيق","🚪 تسجيل الخروج"};
        for (String item: menu) {
            Button b=btn(item); b.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); b.setTextColor(GREEN); b.setBackgroundColor(Color.TRANSPARENT); drawer.addView(b,new LinearLayout.LayoutParams(-1,54));
            b.setOnClickListener(v -> {
                drawerLayout.closeDrawer(Gravity.RIGHT);
                if (item.contains("الرئيسية")) showDashboard();
                else if (item.contains("الخريطة")) showMap();
                else if (item.contains("البلاغات")) showRecords(0);
                else if (item.contains("المهام")) showRecords(1);
                else if (item.contains("المنشآت")) showRecords(2);
                else if (item.contains("التراخيص")) showRecords(3);
                else if (item.contains("النفايات")) showRecords(4);
                else if (item.contains("التقارير")) showReports();
                else if (item.contains("معلومات")) message("EnvironmentSmart 1.1","نظام إدارة أعمال مديرية بيئة اللاذقية\nتنفيذ الأستاذ أحمد جابر غصون");
                else if (item.contains("خروج")) showLogin();
            });
        }
    }

    private void showDashboard() {
        base();
        setupDrawer();
        addTopBar("الصفحة الرئيسية", true);
        LinearLayout panel = root;
        TextView welcome=tv("لوحة الإدارة البيئية",22); welcome.setTextColor(GREEN); welcome.setTypeface(Typeface.DEFAULT_BOLD); panel.addView(welcome,new LinearLayout.LayoutParams(-1,64));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); ScrollView sv=new ScrollView(this); sv.addView(content); panel.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        addDashboardCard("🗺️ الخريطة", "طرق + أقمار صناعية + تضاريس + GPS + حفظ المواقع", v->showMap());
        addDashboardCard("🚨 البلاغات البيئية", "إضافة وتعديل وحذف ومتابعة البلاغات", v->showRecords(0));
        addDashboardCard("👷 المهام الميدانية", "إضافة وتعديل وحذف مهام فرق التفتيش", v->showRecords(1));
        addDashboardCard("🏭 المنشآت", "ملف بيئي لكل منشأة وتقييمها", v->showRecords(2));
        addDashboardCard("📄 التراخيص", "التراخيص والموافقات البيئية", v->showRecords(3));
        addDashboardCard("🗑️ النفايات", "متابعة النفايات والمواقع والكميات", v->showRecords(4));
        addDashboardCard("📊 التقارير والإحصائيات", "ملخص أعداد السجلات ومتوسط التقييم", v->showReports());
        addCreditFooter();
    }

    private void addDashboardCard(String title,String sub,View.OnClickListener click){
        LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(14,8,14,8); c.setBackground(bg(Color.rgb(238,247,240),22));
        TextView a=tv(title,18); a.setTextColor(GREEN); a.setTypeface(Typeface.DEFAULT_BOLD); c.addView(a);
        TextView b=tv(sub,13); b.setTextColor(Color.DKGRAY); c.addView(b);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,92); lp.setMargins(0,7,0,7); content.addView(c,lp); c.setOnClickListener(click);
    }

    private void showRecords(int typeIndex){
        base(); setupDrawer(); addTopBar(TYPE_ICONS[typeIndex]+" "+TYPES[typeIndex],true);
        LinearLayout panel=root;
        TextView info=tv("إدارة السجلات: إضافة / تعديل / حذف / تقييم 0–5",13); info.setTextColor(GREEN); panel.addView(info,new LinearLayout.LayoutParams(-1,52));
        Button add=btn("➕ إضافة سجل جديد"); add.setTextColor(Color.WHITE); add.setBackground(bg(GREEN2,30)); panel.addView(add,new LinearLayout.LayoutParams(-1,56));
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sv.addView(list); panel.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        add.setOnClickListener(v->recordDialog(typeIndex,null,()->renderRecords(typeIndex,list)));
        renderRecords(typeIndex,list);
        addCreditFooter();
    }

    private void renderRecords(int typeIndex, LinearLayout list){
        list.removeAllViews(); List<RecordItem> items=loadRecords(TYPE_KEYS[typeIndex]);
        if(items.isEmpty()){list.addView(tv("لا توجد سجلات بعد. اضغط إضافة سجل جديد.",15),new LinearLayout.LayoutParams(-1,100));return;}
        for(RecordItem r:items){
            LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(12,10,12,10); c.setBackground(bg(CREAM,20));
            TextView title=tv(r.name,18); title.setTextColor(GREEN); title.setTypeface(Typeface.DEFAULT_BOLD); c.addView(title);
            c.addView(tv("⭐ "+String.format(Locale.US,"%.1f",r.rating)+" / 5   •   "+r.status,13));
            if(!r.details.isEmpty()) c.addView(tv(r.details,13));
            c.addView(tv(r.date,11));
            LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER);
            Button edit=btn("✏️ تعديل"), del=btn("🗑️ حذف"); actions.addView(edit,new LinearLayout.LayoutParams(0,48,1)); actions.addView(del,new LinearLayout.LayoutParams(0,48,1)); c.addView(actions);
            edit.setOnClickListener(v->recordDialog(typeIndex,r,()->renderRecords(typeIndex,list)));
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف السجل").setMessage("هل تريد حذف هذا السجل؟").setNegativeButton("إلغاء",null).setPositiveButton("حذف",(d,w)->{deleteRecord(TYPE_KEYS[typeIndex],r.id);renderRecords(typeIndex,list);}).show());
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT);lp.setMargins(0,7,0,7);list.addView(c,lp);
        }
    }

    private void recordDialog(int typeIndex, RecordItem existing, Runnable refresh){
        LinearLayout form=new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(10,4,10,4);
        EditText name=new EditText(this); name.setHint("الاسم / العنوان"); name.setSingleLine(true); form.addView(name);
        EditText details=new EditText(this); details.setHint("الوصف / الملاحظات"); details.setMinLines(3); form.addView(details);
        EditText status=new EditText(this); status.setHint("الحالة (جديد، قيد المتابعة، مكتمل...)"); status.setSingleLine(true); form.addView(status);
        RatingBar rating=new RatingBar(this,null,android.R.attr.ratingBarStyleSmall); rating.setNumStars(5); rating.setStepSize(0.5f); rating.setRating(existing==null?0:existing.rating); form.addView(rating,new LinearLayout.LayoutParams(-1,55));
        if(existing!=null){name.setText(existing.name);details.setText(existing.details);status.setText(existing.status);}
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle(existing==null?"إضافة سجل جديد":"تعديل السجل").setView(form).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim(); if(n.isEmpty()){name.setError("أدخل الاسم");return;}
            RecordItem r=existing==null?new RecordItem():existing; if(r.id==null)r.id=UUID.randomUUID().toString(); r.name=n;r.details=details.getText().toString().trim();r.status=status.getText().toString().trim();if(r.status.isEmpty())r.status="جديد";r.rating=rating.getRating();r.date=new SimpleDateFormat("yyyy/MM/dd HH:mm",Locale.getDefault()).format(new Date());saveRecord(TYPE_KEYS[typeIndex],r);dlg.dismiss();refresh.run();
        })); dlg.show();
    }

    private static class RecordItem { String id="",name="",details="",status="جديد",date=""; float rating=0; }

    private String enc(String s){return android.util.Base64.encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);}
    private String dec(String s){try{return new String(android.util.Base64.decode(s,android.util.Base64.NO_WRAP),java.nio.charset.StandardCharsets.UTF_8);}catch(Exception e){return "";}}
    private String pack(RecordItem r){return enc(r.id)+"|"+enc(r.name)+"|"+enc(r.details)+"|"+enc(r.status)+"|"+r.rating+"|"+enc(r.date);}
    private RecordItem unpack(String x){String[] p=x.split("\\|",-1);if(p.length<6)return null;try{RecordItem r=new RecordItem();r.id=dec(p[0]);r.name=dec(p[1]);r.details=dec(p[2]);r.status=dec(p[3]);r.rating=Float.parseFloat(p[4]);r.date=dec(p[5]);return r;}catch(Exception e){return null;}}
    private List<RecordItem> loadRecords(String key){List<RecordItem> out=new ArrayList<>();Set<String>s=prefs.getStringSet(key,new HashSet<>());for(String x:s){RecordItem r=unpack(x);if(r!=null)out.add(r);}return out;}
    private void saveRecord(String key,RecordItem item){List<RecordItem> all=loadRecords(key);boolean replaced=false;for(int i=0;i<all.size();i++)if(all.get(i).id.equals(item.id)){all.set(i,item);replaced=true;break;}if(!replaced)all.add(item);Set<String>s=new HashSet<>();for(RecordItem r:all)s.add(pack(r));prefs.edit().putStringSet(key,s).apply();}
    private void deleteRecord(String key,String id){Set<String>s=prefs.getStringSet(key,new HashSet<>());Set<String> n=new HashSet<>();for(String x:s){RecordItem r=unpack(x);if(r!=null&&!r.id.equals(id))n.add(x);}prefs.edit().putStringSet(key,n).apply();}

    private void showReports(){
        base(); setupDrawer(); addTopBar("📊 التقارير والإحصائيات",true);
        LinearLayout panel=root; ScrollView sv=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);sv.addView(box);panel.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        int total=0;double sum=0;StringBuilder report=new StringBuilder("ملخص أعمال مديرية البيئة\n\n");
        for(int i=0;i<TYPES.length;i++){List<RecordItem> rs=loadRecords(TYPE_KEYS[i]);double s=0;for(RecordItem r:rs)s+=r.rating;total+=rs.size();sum+=s;report.append(TYPE_ICONS[i]).append(" ").append(TYPES[i]).append(": ").append(rs.size()).append(" سجل\n");}
        double avg=total==0?0:sum/total;report.append("\nإجمالي السجلات: ").append(total).append("\nمتوسط التقييم: ").append(String.format(Locale.US,"%.2f / 5",avg));
        TextView r=tv(report.toString(),17);r.setGravity(Gravity.RIGHT);r.setTextColor(GREEN);r.setPadding(18,24,18,24);r.setBackground(bg(CREAM,24));box.addView(r);
        box.addView(tv("التقارير قابلة للتوسع لاحقًا إلى تصدير PDF/Excel وربط الخريطة بالسجلات.",13));
        addCreditFooter();
    }

    private void showMap(){
        Configuration.getInstance().load(this,getSharedPreferences("osmdroid",MODE_PRIVATE)); base(); addMode=false;
        addTopBar("🗺️ الخريطة البيئية",false);
        LinearLayout layers=new LinearLayout(this);layers.setOrientation(LinearLayout.HORIZONTAL);Button roads=btn("🗺️ طرق"),sat=btn("🛰️ أقمار"),terrain=btn("⛰️ تضاريس");layers.addView(roads,new LinearLayout.LayoutParams(0,54,1));layers.addView(sat,new LinearLayout.LayoutParams(0,54,1));layers.addView(terrain,new LinearLayout.LayoutParams(0,54,1));root.addView(layers);
        LinearLayout actions=new LinearLayout(this);Button gps=btn("📍 GPS"),add=btn("➕ إضافة"),search=btn("🔎 بحث"),saved=btn("🔖 المحفوظة");actions.addView(gps,new LinearLayout.LayoutParams(0,54,1));actions.addView(add,new LinearLayout.LayoutParams(0,54,1));actions.addView(search,new LinearLayout.LayoutParams(0,54,1));actions.addView(saved,new LinearLayout.LayoutParams(0,54,1));root.addView(actions);
        map=new MapView(this);map.setTileSource(TileSourceFactory.MAPNIK);map.setMultiTouchControls(true);map.setBuiltInZoomControls(true);map.setMinZoomLevel(5);map.setMaxZoomLevel(18);map.getController().setZoom(7);map.getController().setCenter(new GeoPoint(34.8021,38.9968));root.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        Button back=btn("العودة إلى الرئيسية");root.addView(back,new LinearLayout.LayoutParams(-1,54));addCreditFooter();
        loadSavedMarkers();setupLocation();installMapEvents();
        roads.setOnClickListener(v->{map.setTileSource(TileSourceFactory.MAPNIK);map.invalidate();});sat.setOnClickListener(v->{map.setTileSource(SATELLITE);map.invalidate();});terrain.setOnClickListener(v->{map.setTileSource(TileSourceFactory.OpenTopo);map.invalidate();});
        gps.setOnClickListener(v->{if(myLocationOverlay!=null&&myLocationOverlay.getMyLocation()!=null){map.getController().animateTo(myLocationOverlay.getMyLocation());map.getController().setZoom(15);}else{requestLocationPermission();Toast.makeText(this,"جارٍ تحديد الموقع...",Toast.LENGTH_SHORT).show();}});
        add.setOnClickListener(v->{addMode=true;Toast.makeText(this,"اضغط مطولاً على المكان المطلوب",Toast.LENGTH_LONG).show();});search.setOnClickListener(v->searchLocation());saved.setOnClickListener(v->showSavedPlaces());back.setOnClickListener(v->{if(map!=null)map.onDetach();showDashboard();});
    }

    private void showSavedPlaces(){List<Marker> ms=new ArrayList<>(savedMarkers);if(ms.isEmpty()){message("المواقع المحفوظة","لا توجد مواقع محفوظة بعد.");return;}String[] names=new String[ms.size()];for(int i=0;i<ms.size();i++)names[i]=ms.get(i).getTitle();new AlertDialog.Builder(this).setTitle("المواقع المحفوظة").setItems(names,(d,w)->{Marker m=ms.get(w);map.getController().animateTo(m.getPosition());map.getController().setZoom(15);m.showInfoWindow();}).setNegativeButton("إغلاق",null).show();}

    private void installMapEvents(){MapEventsOverlay e=new MapEventsOverlay(new MapEventsReceiver(){public boolean singleTapConfirmedHelper(GeoPoint p){return false;}public boolean longPressHelper(GeoPoint p){if(!addMode)return false;addMode=false;askPlaceName(p);return true;}});map.getOverlays().add(e);}
    private void searchLocation(){EditText input=new EditText(this);input.setHint("مثال: اللاذقية أو حلب");new AlertDialog.Builder(this).setTitle("البحث عن موقع").setView(input).setPositiveButton("بحث",(d,w)->{String q=input.getText().toString().trim();if(q.isEmpty())return;searchExecutor.execute(()->{try{android.location.Geocoder g=new android.location.Geocoder(this,Locale.getDefault());List<android.location.Address> r=g.getFromLocationName(q,5,32.3,35.6,37.4,42.5);runOnUiThread(()->{if(r==null||r.isEmpty()){Toast.makeText(this,"لم يتم العثور على الموقع",Toast.LENGTH_LONG).show();return;}GeoPoint p=new GeoPoint(r.get(0).getLatitude(),r.get(0).getLongitude());map.getController().animateTo(p);map.getController().setZoom(13);});}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"تعذر البحث. تأكد من الإنترنت.",Toast.LENGTH_LONG).show());}});}).setNegativeButton("إلغاء",null).show();}
    private void askPlaceName(GeoPoint p){EditText input=new EditText(this);input.setHint("اسم الموقع / المنشأة");new AlertDialog.Builder(this).setTitle("حفظ موقع جديد").setView(input).setPositiveButton("حفظ",(d,w)->{String n=input.getText().toString().trim();if(n.isEmpty())n="موقع بيئي";saveMarker(n,p);}).setNegativeButton("إلغاء",null).show();}
    private void saveMarker(String name,GeoPoint p){Marker m=new Marker(map);m.setPosition(p);m.setTitle(name);m.setSnippet(String.format(Locale.US,"%.6f, %.6f",p.getLatitude(),p.getLongitude()));m.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM);m.setOnMarkerClickListener((x,mv)->{new AlertDialog.Builder(this).setTitle(x.getTitle()).setMessage("الإحداثيات: "+x.getSnippet()).setPositiveButton("تعديل",(d,w)->editMarker(x)).setNegativeButton("حذف",(d,w)->{map.getOverlays().remove(x);savedMarkers.remove(x);persistMarkers();map.invalidate();}).setNeutralButton("إغلاق",null).show();return true;});map.getOverlays().add(m);savedMarkers.add(m);persistMarkers();map.getController().animateTo(p);map.invalidate();}
    private void editMarker(Marker m){EditText i=new EditText(this);i.setText(m.getTitle());new AlertDialog.Builder(this).setTitle("تعديل الموقع").setView(i).setPositiveButton("حفظ",(d,w)->{String n=i.getText().toString().trim();if(!n.isEmpty())m.setTitle(n);persistMarkers();map.invalidate();}).setNegativeButton("إلغاء",null).show();}
    private void persistMarkers(){Set<String>s=new HashSet<>();for(Marker m:savedMarkers){GeoPoint p=m.getPosition();s.add(enc(m.getTitle())+"|"+p.getLatitude()+"|"+p.getLongitude());}prefs.edit().putStringSet("places",s).apply();}
    private void loadSavedMarkers(){Set<String>s=prefs.getStringSet("places",new HashSet<>());for(String x:s){String[]p=x.split("\\|",-1);if(p.length!=3)continue;try{saveMarkerSilently(dec(p[0]),new GeoPoint(Double.parseDouble(p[1]),Double.parseDouble(p[2])));}catch(Exception ignored){}}}
    private void saveMarkerSilently(String name,GeoPoint p){Marker m=new Marker(map);m.setPosition(p);m.setTitle(name);m.setSnippet(String.format(Locale.US,"%.6f, %.6f",p.getLatitude(),p.getLongitude()));m.setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_BOTTOM);m.setOnMarkerClickListener((x,mv)->{new AlertDialog.Builder(this).setTitle(x.getTitle()).setMessage("الإحداثيات: "+x.getSnippet()).setPositiveButton("تعديل",(d,w)->editMarker(x)).setNegativeButton("حذف",(d,w)->{map.getOverlays().remove(x);savedMarkers.remove(x);persistMarkers();map.invalidate();}).setNeutralButton("إغلاق",null).show();return true;});map.getOverlays().add(m);savedMarkers.add(m);}
    private void setupLocation(){myLocationOverlay=new MyLocationNewOverlay(new GpsMyLocationProvider(this),map);myLocationOverlay.enableMyLocation();map.getOverlays().add(myLocationOverlay);if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED||ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED)myLocationOverlay.enableFollowLocation();else requestLocationPermission();}
    private void requestLocationPermission(){if(android.os.Build.VERSION.SDK_INT>=23)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_REQUEST);}
    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);if(r==LOCATION_REQUEST&&myLocationOverlay!=null&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED){myLocationOverlay.enableMyLocation();myLocationOverlay.enableFollowLocation();}}
    private void message(String t,String m){new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("حسنًا",null).show();}
    @Override protected void onResume(){super.onResume();if(map!=null)map.onResume();}
    @Override protected void onPause(){if(map!=null)map.onPause();super.onPause();}
    @Override protected void onDestroy(){searchExecutor.shutdownNow();super.onDestroy();}
}
