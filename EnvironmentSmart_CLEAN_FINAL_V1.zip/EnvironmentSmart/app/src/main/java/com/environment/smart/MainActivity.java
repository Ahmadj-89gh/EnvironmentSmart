package com.environment.smart;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_LOCATION = 100;
    private static final int REQ_FILE = 101;
    private LinearLayout root;
    private SharedPreferences prefs;
    private LocationManager locationManager;
    private WebView mapView;
    private String attachedUri = "";
    private String role = "";
    private int screen = 0;

    private final int GREEN = Color.rgb(35,120,80);
    private final int DARK = Color.rgb(20,80,55);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("environment_smart", MODE_PRIVATE);
        locationManager = (LocationManager)getSystemService(LOCATION_SERVICE);
        if (prefs.getBoolean("logged_in", false)) {
            role = prefs.getString("role", "citizen");
            mainMenu();
        } else login();
    }

    private GradientDrawable bg(int c, float r){ GradientDrawable d=new GradientDrawable(); d.setColor(c); d.setCornerRadius(r); return d; }
    private void base(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(22,22,22,22); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(Color.rgb(235,247,240));
        ScrollView s=new ScrollView(this); s.setFillViewport(true); s.addView(root); setContentView(s);
    }
    private TextView title(String x){ TextView t=new TextView(this); t.setText(x); t.setTextSize(20); t.setTextColor(DARK); t.setGravity(Gravity.CENTER); t.setTypeface(null,1); t.setPadding(10,16,10,16); t.setBackground(bg(Color.WHITE,28)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,0,0,14); t.setLayoutParams(p); return t; }
    private Button btn(String x){ Button b=new Button(this); b.setText(x); b.setTextSize(16); b.setTextColor(DARK); b.setAllCaps(false); b.setBackground(bg(Color.WHITE,24)); b.setPadding(10,8,10,8); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5); b.setLayoutParams(p); return b; }
    private Button greenBtn(String x){ Button b=btn(x); b.setTextColor(Color.WHITE); b.setBackground(bg(GREEN,24)); return b; }
    private EditText input(String h){ EditText e=new EditText(this); e.setHint(h); e.setTextSize(16); e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); e.setPadding(16,10,16,10); e.setBackground(bg(Color.WHITE,20)); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.setMargins(0,5,0,5); e.setLayoutParams(p); return e; }
    private void footer(){ TextView t=new TextView(this); t.setText("\nتنفيذ الأستاذ أحمد جابر غصون"); t.setTextSize(14); t.setTextColor(Color.DKGRAY); t.setGravity(Gravity.CENTER); t.setPadding(5,25,5,10); root.addView(t); }
    private void toast(String x){ Toast.makeText(this,x,Toast.LENGTH_SHORT).show(); }

    private void login(){ screen=0; base(); root.addView(title("الجمهورية العربية السورية\nوزارة الإدارة المحلية والبيئة\nمديرية بيئة اللاذقية")); TextView a=new TextView(this); a.setText("🌿 البيئة الذكية"); a.setTextSize(28); a.setTextColor(GREEN); a.setGravity(Gravity.CENTER); a.setTypeface(null,1); a.setPadding(5,15,5,20); root.addView(a);
        EditText u=input("اسم المستخدم"); EditText p=input("كلمة المرور"); p.setInputType(0x81); root.addView(u); root.addView(p);
        Button in=greenBtn("🔐 تسجيل الدخول"); Button reg=btn("👤 إنشاء حساب مواطن"); root.addView(in); root.addView(reg);
        TextView hint=new TextView(this); hint.setText("دخول الموظف التجريبي: admin / admin123"); hint.setTextColor(Color.GRAY); hint.setGravity(Gravity.CENTER); hint.setPadding(5,12,5,12); root.addView(hint);
        in.setOnClickListener(v->{String user=u.getText().toString().trim(), pass=p.getText().toString(); if(user.isEmpty()||pass.isEmpty()){toast("أدخل اسم المستخدم وكلمة المرور");return;} if(user.equals("admin")&&pass.equals("admin123")){role="employee";} else if(checkCitizen(user,pass)){role="citizen";} else {toast("بيانات الدخول غير صحيحة");return;} prefs.edit().putBoolean("logged_in",true).putString("username",user).putString("role",role).apply(); mainMenu();});
        reg.setOnClickListener(v->register()); footer();
    }
    private boolean checkCitizen(String u,String p){ try{JSONArray a=new JSONArray(prefs.getString("users","[]")); for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i); if(o.optString("u").equals(u)&&o.optString("p").equals(p)) return true;}}catch(Exception ignored){} return false; }
    private void register(){ screen=1; base(); root.addView(title("👤 إنشاء حساب مواطن")); EditText n=input("الاسم الكامل"); EditText u=input("اسم المستخدم"); EditText p=input("كلمة المرور"); EditText c=input("تأكيد كلمة المرور"); p.setInputType(0x81); c.setInputType(0x81); root.addView(n);root.addView(u);root.addView(p);root.addView(c); Button save=greenBtn("✅ إنشاء الحساب");Button back=btn("⬅ العودة");root.addView(save);root.addView(back);
        save.setOnClickListener(v->{String name=n.getText().toString().trim(), user=u.getText().toString().trim(), pass=p.getText().toString(), con=c.getText().toString(); if(name.isEmpty()||user.isEmpty()||pass.isEmpty()){toast("املأ الحقول المطلوبة");return;} if(!pass.equals(con)){toast("كلمتا المرور غير متطابقتين");return;} try{JSONArray a=new JSONArray(prefs.getString("users","[]")); for(int i=0;i<a.length();i++) if(a.getJSONObject(i).optString("u").equals(user)){toast("اسم المستخدم موجود مسبقاً");return;} JSONObject o=new JSONObject();o.put("name",name);o.put("u",user);o.put("p",pass);a.put(o);prefs.edit().putString("users",a.toString()).apply();toast("تم إنشاء الحساب");login();}catch(Exception e){toast("تعذر إنشاء الحساب");}}); back.setOnClickListener(v->login()); footer();
    }

    private void mainMenu(){ if(!prefs.getBoolean("logged_in",false)){login();return;} screen=2;base(); root.addView(title("الجمهورية العربية السورية\nوزارة الإدارة المحلية والبيئة\nمديرية بيئة اللاذقية")); TextView a=new TextView(this);a.setText("🌿 البيئة الذكية");a.setTextSize(28);a.setTextColor(GREEN);a.setGravity(Gravity.CENTER);a.setTypeface(null,1);a.setPadding(5,10,5,15);root.addView(a); TextView w=new TextView(this);w.setText("مرحباً "+prefs.getString("username",""));w.setTextSize(17);w.setGravity(Gravity.CENTER);w.setTextColor(Color.DKGRAY);root.addView(w);
        if(role.equals("citizen")) citizenMenu(); else employeeMenu();
        Button out=btn("🚪 تسجيل الخروج");root.addView(out);out.setOnClickListener(v->logout());footer();
    }
    private void citizenMenu(){
        add("👤 بوابة المواطن",this::citizenPortal); add("📝 تقديم طلب جديد",()->requestForm("طلب خدمة")); add("❓ استفسار",()->requestForm("استفسار")); add("📢 شكوى أو بلاغ",()->requestForm("شكوى أو بلاغ")); add("📄 طلب ترخيص",()->requestForm("طلب ترخيص")); add("📅 طلب موعد",()->requestForm("طلب موعد")); add("🔎 متابعة معاملة",this::track); add("📋 طلباتي",this::myRequests); add("🗺 الخريطة والموقع",this::mapScreen); add("📎 الوثائق المرفقة",this::attachmentInfo);
    }
    private void employeeMenu(){
        add("🗺 الخريطة والمواقع",this::mapScreen); add("📍 GPS",this::gps); addData("📌 المواقع","locations"); addData("📢 البلاغات","reports"); addData("📝 المهام الميدانية","tasks"); addData("🏢 المنشآت","facilities"); addData("📄 التراخيص","licenses"); addData("♻ النفايات","waste"); add("👤 طلبات المواطنين",this::allRequests); add("⭐ التقييم",this::rating); add("📊 التقارير والإحصائيات",this::stats);
    }
    private void add(String text, final Runnable r){Button b=btn(text);root.addView(b);b.setOnClickListener(v->r.run());}
    private void addData(String label,String key){add(label,()->dataPage(label,key));}

    private void citizenPortal(){base();root.addView(title("👤 بوابة المواطن")); TextView t=new TextView(this);t.setText("من هنا يستطيع المواطن تقديم احتياجاته ومتابعة معاملاته إلكترونياً.");t.setTextSize(18);t.setTextColor(DARK);t.setGravity(Gravity.CENTER);t.setPadding(10,20,10,20);root.addView(t); add("📝 طلب خدمة",()->requestForm("طلب خدمة"));add("❓ استفسار",()->requestForm("استفسار"));add("📢 شكوى أو بلاغ",()->requestForm("شكوى أو بلاغ"));add("📄 طلب ترخيص",()->requestForm("طلب ترخيص"));add("📅 طلب موعد",()->requestForm("طلب موعد"));add("🔎 متابعة معاملة",this::track);add("📋 طلباتي",this::myRequests);add("📎 إرفاق وثيقة/صورة",this::pickFile);add("⬅ الرئيسية",this::mainMenu);footer();}

    private void requestForm(String type){base();root.addView(title("📝 "+type)); EditText name=input("الاسم الكامل");EditText phone=input("رقم الهاتف");EditText subject=input("موضوع الطلب");EditText details=input("التفاصيل");details.setMinLines(4);details.setGravity(Gravity.RIGHT|Gravity.TOP);root.addView(name);root.addView(phone);root.addView(subject);root.addView(details); TextView att=new TextView(this);att.setText(attachedUri.isEmpty()?"لا يوجد مرفق":"📎 تم اختيار مرفق");att.setGravity(Gravity.CENTER);att.setTextColor(DARK);att.setPadding(5,12,5,12);root.addView(att);Button file=btn("📎 إرفاق وثيقة/صورة/ملف");Button gps=btn("📍 إضافة موقعي الحالي");Button send=greenBtn("📨 إرسال الطلب");Button back=btn("⬅ العودة");root.addView(file);root.addView(gps);root.addView(send);root.addView(back);
        file.setOnClickListener(v->{pickFile();att.setText("📎 تم اختيار مرفق");}); gps.setOnClickListener(v->getLocationToast()); send.setOnClickListener(v->{String n=name.getText().toString().trim(),s=subject.getText().toString().trim(),d=details.getText().toString().trim();if(n.isEmpty()||s.isEmpty()||d.isEmpty()){toast("أدخل الاسم والموضوع والتفاصيل");return;}String id="ENV-"+System.currentTimeMillis();try{JSONArray a=new JSONArray(prefs.getString("requests","[]"));JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("name",n);o.put("phone",phone.getText().toString().trim());o.put("subject",s);o.put("details",d);o.put("attachment",attachedUri);o.put("status","قيد الاستلام");o.put("user",prefs.getString("username",""));a.put(o);prefs.edit().putString("requests",a.toString()).apply();attachedUri="";toast("تم إرسال الطلب\nرقم المعاملة: "+id);citizenPortal();}catch(Exception e){toast("تعذر حفظ الطلب");}});back.setOnClickListener(v->citizenPortal());footer();}

    private void pickFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,REQ_FILE);}
    @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==REQ_FILE&&c==RESULT_OK&&data!=null&&data.getData()!=null){Uri u=data.getData();attachedUri=u.toString();try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}toast("تم اختيار المرفق");}}
    private void attachmentInfo(){base();root.addView(title("📎 المرفقات"));TextView t=new TextView(this);t.setText("يمكن للمواطن إرفاق وثيقة أو صورة أو ملف مع الطلب.\n\nالمرفق الحالي: "+(attachedUri.isEmpty()?"لا يوجد":attachedUri));t.setTextSize(17);t.setTextColor(DARK);t.setGravity(Gravity.CENTER);t.setPadding(15,25,15,25);root.addView(t);add("📎 اختيار مرفق",this::pickFile);add("⬅ الرئيسية",this::mainMenu);footer();}

    private void track(){base();root.addView(title("🔎 متابعة معاملة"));EditText id=input("رقم المعاملة ENV-...");root.addView(id);Button b=greenBtn("🔎 بحث");root.addView(b);add("⬅ العودة",this::citizenPortal);b.setOnClickListener(v->{String q=id.getText().toString().trim();try{JSONArray a=new JSONArray(prefs.getString("requests","[]"));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optString("id").equals(q)){showRequest(o);return;}}toast("لم يتم العثور على المعاملة");}catch(Exception e){toast("تعذر البحث");}});footer();}
    private void myRequests(){base();root.addView(title("📋 طلباتي"));try{JSONArray a=new JSONArray(prefs.getString("requests","[]"));boolean any=false;for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(o.optString("user").equals(prefs.getString("username",""))){any=true;row(o);}}if(!any)empty("لا توجد طلبات حتى الآن");}catch(Exception e){empty("تعذر قراءة الطلبات");}add("⬅ الرئيسية",this::mainMenu);footer();}
    private void allRequests(){base();root.addView(title("👤 طلبات المواطنين"));try{JSONArray a=new JSONArray(prefs.getString("requests","[]"));if(a.length()==0)empty("لا توجد طلبات");for(int i=0;i<a.length();i++)row(a.getJSONObject(i));}catch(Exception e){empty("تعذر قراءة الطلبات");}add("⬅ الرئيسية",this::mainMenu);footer();}
    private void row(JSONObject o){TextView t=new TextView(this);t.setText("رقم: "+o.optString("id")+"\nالخدمة: "+o.optString("type")+"\nالمواطن: "+o.optString("name")+"\nالموضوع: "+o.optString("subject")+"\nالحالة: "+o.optString("status"));t.setTextSize(16);t.setTextColor(DARK);t.setGravity(Gravity.RIGHT);t.setPadding(16,16,16,16);t.setBackground(bg(Color.WHITE,20));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,5,0,5);t.setLayoutParams(p);root.addView(t);}
    private void showRequest(JSONObject o){base();root.addView(title("📄 تفاصيل المعاملة"));row(o);add("⬅ الرئيسية",this::mainMenu);footer();}
    private void empty(String x){TextView t=new TextView(this);t.setText(x);t.setTextSize(18);t.setGravity(Gravity.CENTER);t.setTextColor(Color.GRAY);t.setPadding(10,30,10,30);root.addView(t);}

    private void dataPage(String label,String key){base();root.addView(title(label));List<String> list=getList(key);if(list.isEmpty())empty("لا توجد بيانات حالياً");else for(String s:list){TextView t=new TextView(this);t.setText("• "+s);t.setTextSize(17);t.setTextColor(DARK);t.setGravity(Gravity.RIGHT);t.setPadding(16,16,16,16);t.setBackground(bg(Color.WHITE,20));root.addView(t);}add("➕ إضافة",()->addDataItem(label,key));add("🗑 حذف آخر عنصر",()->{List<String> l=getList(key);if(l.isEmpty())toast("لا يوجد عنصر");else{l.remove(l.size()-1);saveList(key,l);dataPage(label,key);}});add("⬅ الرئيسية",this::mainMenu);footer();}
    private void addDataItem(String label,String key){base();root.addView(title("➕ "+label));EditText e=input("اكتب البيانات");root.addView(e);Button s=greenBtn("💾 حفظ");root.addView(s);add("⬅ العودة",()->dataPage(label,key));s.setOnClickListener(v->{String x=e.getText().toString().trim();if(x.isEmpty()){toast("أدخل البيانات");return;}List<String> l=getList(key);l.add(x);saveList(key,l);dataPage(label,key);});footer();}
    private List<String> getList(String key){List<String> l=new ArrayList<>();try{JSONArray a=new JSONArray(prefs.getString(key,"[]"));for(int i=0;i<a.length();i++)l.add(a.getString(i));}catch(Exception ignored){}return l;}
    private void saveList(String key,List<String> l){JSONArray a=new JSONArray();for(String s:l)a.put(s);prefs.edit().putString(key,a.toString()).apply();}

    private void rating(){base();root.addView(title("⭐ التقييم"));TextView t=new TextView(this);t.setText("قيّم الخدمة من 0 إلى 5");t.setTextSize(18);t.setGravity(Gravity.CENTER);root.addView(t);SeekBar s=new SeekBar(this);s.setMax(5);root.addView(s);TextView v=new TextView(this);v.setText("التقييم: 0 / 5");v.setTextSize(22);v.setGravity(Gravity.CENTER);v.setTextColor(GREEN);root.addView(v);s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int p,boolean u){v.setText("التقييم: "+p+" / 5");}public void onStartTrackingTouch(SeekBar x){}public void onStopTrackingTouch(SeekBar x){}});add("⬅ الرئيسية",this::mainMenu);footer();}
    private void stats(){base();root.addView(title("📊 التقارير والإحصائيات"));int r=count("requests");String text="طلبات المواطنين: "+r+"\n\nالمواقع: "+getList("locations").size()+"\n\nالبلاغات: "+getList("reports").size()+"\n\nالمهام: "+getList("tasks").size()+"\n\nالمنشآت: "+getList("facilities").size()+"\n\nالتراخيص: "+getList("licenses").size()+"\n\nالنفايات: "+getList("waste").size();TextView t=new TextView(this);t.setText(text);t.setTextSize(19);t.setTextColor(DARK);t.setGravity(Gravity.RIGHT);t.setPadding(20,25,20,30);t.setBackground(bg(Color.WHITE,22));root.addView(t);add("⬅ الرئيسية",this::mainMenu);footer();}
    private int count(String key){try{return new JSONArray(prefs.getString(key,"[]")).length();}catch(Exception e){return 0;}}

    private void mapScreen(){base();root.addView(title("🗺 الخريطة"));LinearLayout modes=new LinearLayout(this);modes.setOrientation(LinearLayout.HORIZONTAL);modes.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);Button normal=btn("خريطة");Button sat=btn("قمر صناعي");Button terrain=btn("تضاريس");modes.addView(normal,new LinearLayout.LayoutParams(0,-2,1));modes.addView(sat,new LinearLayout.LayoutParams(0,-2,1));modes.addView(terrain,new LinearLayout.LayoutParams(0,-2,1));root.addView(modes);mapView=new WebView(this);mapView.setWebViewClient(new WebViewClient());WebSettings ws=mapView.getSettings();ws.setJavaScriptEnabled(true);ws.setDomStorageEnabled(true);root.addView(mapView,new LinearLayout.LayoutParams(-1,650));String html=mapHtml("normal");mapView.loadDataWithBaseURL("https://localhost/",html,"text/html","UTF-8",null);normal.setOnClickListener(v->loadMap("normal"));sat.setOnClickListener(v->loadMap("sat"));terrain.setOnClickListener(v->loadMap("terrain"));add("📍 موقعي الحالي",this::getLocationToast);add("⬅ الرئيسية",this::mainMenu);footer();}
    private void loadMap(String mode){if(mapView!=null)mapView.loadDataWithBaseURL("https://localhost/",mapHtml(mode),"text/html","UTF-8",null);}
    private String mapHtml(String mode){String url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",attr="© OpenStreetMap contributors";if(mode.equals("sat")){url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}";attr="© Esri";}if(mode.equals("terrain")){url="https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png";attr="© OpenTopoMap";}return "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'></head><body style='margin:0'><div id='m' style='width:100%;height:100vh'></div><script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script><script>var m=L.map('m').setView([35.52,35.78],10);L.tileLayer('"+url+"',{maxZoom:19,attribution:'"+attr+"'}).addTo(m);</script></body></html>";}

    private void gps(){getLocationToast();}
    private void getLocationToast(){if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_LOCATION);return;}try{Location l=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(l==null)l=locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);if(l!=null)toast(String.format(Locale.US,"موقعي: %.6f, %.6f",l.getLatitude(),l.getLongitude()));else{toast("جاري تحديد الموقع...");locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,5,new LocationListener(){public void onLocationChanged(Location x){toast(String.format(Locale.US,"موقعي: %.6f, %.6f",x.getLatitude(),x.getLongitude()));locationManager.removeUpdates(this);}public void onProviderEnabled(String p){}public void onProviderDisabled(String p){}public void onStatusChanged(String p,int s,Bundle b){}});}}catch(Exception e){toast("تعذر الوصول إلى الموقع");}}

    private void logout(){prefs.edit().putBoolean("logged_in",false).remove("username").remove("role").apply();role="";screen=0;login();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_LOCATION){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)getLocationToast();else toast("يجب السماح بالموقع لاستخدام GPS");}}
    @Override public void onBackPressed(){if(!prefs.getBoolean("logged_in",false)){if(screen==1)login();else moveTaskToBack(true);return;}mainMenu();}
}
