package com.environment.smart;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import android.util.Base64;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 1001;
    private static final int GREEN = Color.rgb(11, 61, 46);
    private static final int PALE = Color.rgb(238, 247, 240);

    private LinearLayout root, content;
    private MapView map;
    private MyLocationNewOverlay myLocationOverlay;
    private final ArrayList<Marker> savedMarkers = new ArrayList<>();
    private SharedPreferences prefs;
    private boolean addMode = false;
    private final ExecutorService searchExecutor = Executors.newSingleThreadExecutor();

    private static final OnlineTileSourceBase SATELLITE = new OnlineTileSourceBase(
            "ArcGIS World Imagery", 1, 18, 256, ".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"},
            "Esri World Imagery") {
        @Override
        public String getTileURLString(final long tile) {
            return getBaseUrl() + MapTileIndex.getZoom(tile) + "/"
                    + MapTileIndex.getY(tile) + "/" + MapTileIndex.getX(tile) + mImageFilenameEnding;
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        prefs = getSharedPreferences("saved_places", MODE_PRIVATE);
        showLogin();
    }

    private TextView tv(String text, float size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(20, 14, 20, 14);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(15);
        b.setAllCaps(false);
        return b;
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 18);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);
    }

    private void showLogin() {
        base();
        Space top = new Space(this);
        root.addView(top, new LinearLayout.LayoutParams(1, 0, 1));
        TextView title = tv("🌿 البيئة الذكية", 30);
        title.setTextColor(GREEN);
        root.addView(title, new LinearLayout.LayoutParams(-1, 75));
        root.addView(tv("نظام رقمي لإدارة أعمال مديرية البيئة", 17));
        EditText u = new EditText(this);
        u.setHint("اسم المستخدم");
        u.setSingleLine(true);
        EditText p = new EditText(this);
        p.setHint("كلمة المرور");
        p.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        p.setSingleLine(true);
        root.addView(u, new LinearLayout.LayoutParams(-1, 60));
        root.addView(p, new LinearLayout.LayoutParams(-1, 60));
        Button login = btn("دخول");
        root.addView(login, new LinearLayout.LayoutParams(-1, 62));
        root.addView(tv("بيانات التجربة: admin / admin123", 13));
        root.addView(new Space(this), new LinearLayout.LayoutParams(1, 0, 1));
        login.setOnClickListener(v -> {
            boolean ok = u.getText().toString().trim().equals("admin") && p.getText().toString().equals("admin123");
            if (ok) showDashboard();
            else Toast.makeText(this, "بيانات الدخول: admin / admin123", Toast.LENGTH_LONG).show();
        });
    }

    private void showDashboard() {
        base();
        TextView h = tv("🌿 البيئة الذكية\nلوحة الإدارة البيئية", 24);
        h.setTextColor(Color.WHITE);
        h.setBackground(bg(GREEN, 28));
        root.addView(h, new LinearLayout.LayoutParams(-1, 110));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        addCard("🗺️ الخريطة البيئية", "طرق + أقمار صناعية + تضاريس + GPS + مواقع محفوظة", v -> showMap());
        addCard("🚨 البلاغات البيئية", "تسجيل ومتابعة البلاغات", v -> module("البلاغات البيئية", "من هنا سيتم تسجيل البلاغ وموقعه وصوره وحالته."));
        addCard("👷 المهام الميدانية", "توزيع ومتابعة أعمال الفرق", v -> module("المهام الميدانية", "إنشاء مهمة، تحديد الموقع، المسؤول، الحالة وموعد التنفيذ."));
        addCard("🏭 المنشآت", "الملف البيئي لكل منشأة", v -> module("المنشآت", "اسم المنشأة، النشاط، الموقع، الحالة، الملاحظات والوثائق."));
        addCard("📄 التراخيص", "التراخيص والموافقات البيئية", v -> module("التراخيص", "متابعة الطلبات والموافقات وتواريخ الانتهاء."));
        addCard("🗑️ النفايات", "الجمع والنقل والمكبات والمعالجة", v -> module("النفايات", "تسجيل مواقع النفايات ومتابعة الجمع والنقل والمعالجة."));
        addCard("📊 التقارير", "مؤشرات وإحصائيات", v -> module("التقارير", "تقارير عن المواقع والبلاغات والمهام والمنشآت."));

        Button logout = btn("تسجيل الخروج");
        root.addView(logout, new LinearLayout.LayoutParams(-1, 60));
        logout.setOnClickListener(v -> showLogin());
    }

    private void addCard(String title, String sub, View.OnClickListener listener) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12, 8, 12, 8);
        box.setBackground(bg(PALE, 22));
        TextView a = tv(title, 19);
        a.setTextColor(GREEN);
        box.addView(a);
        box.addView(tv(sub, 13));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 92);
        lp.setMargins(0, 8, 0, 0);
        content.addView(box, lp);
        box.setOnClickListener(listener);
    }

    private void module(String title, String text) {
        if (title.equals("التقارير")) { showReports(); return; }
        String key;
        String[] labels;
        if (title.equals("البلاغات البيئية")) {
            key = "complaints"; labels = new String[]{"عنوان البلاغ", "التفاصيل", "الموقع", "الحالة"};
        } else if (title.equals("المهام الميدانية")) {
            key = "tasks"; labels = new String[]{"اسم المهمة", "المسؤول", "الموقع", "الحالة"};
        } else if (title.equals("المنشآت")) {
            key = "facilities"; labels = new String[]{"اسم المنشأة", "النشاط", "الموقع", "الحالة", "ملاحظات"};
        } else if (title.equals("التراخيص")) {
            key = "licenses"; labels = new String[]{"اسم المنشأة", "نوع الترخيص", "رقم الترخيص", "تاريخ الانتهاء", "الحالة"};
        } else if (title.equals("النفايات")) {
            key = "waste"; labels = new String[]{"الموقع", "نوع النفايات", "الكمية", "الحالة", "ملاحظات"};
        } else {
            new AlertDialog.Builder(this).setTitle(title).setMessage(text).setPositiveButton("حسنًا", null).show();
            return;
        }
        showDataModule(title, key, labels);
    }

    private void showDataModule(String title, String key, String[] labels) {
        base();
        TextView h = tv(title, 24); h.setTextColor(Color.WHITE); h.setBackground(bg(GREEN, 24));
        root.addView(h, new LinearLayout.LayoutParams(-1, 72));
        Button add = btn("➕ إضافة سجل جديد"); root.addView(add, new LinearLayout.LayoutParams(-1, 58));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Button back = btn("↩ العودة إلى لوحة الإدارة"); root.addView(back, new LinearLayout.LayoutParams(-1, 58));
        final Runnable[] refresh = new Runnable[1];
        refresh[0] = () -> {
            list.removeAllViews(); ArrayList<String> records = getRecords(key);
            if (records.isEmpty()) { list.addView(tv("لا توجد سجلات حتى الآن.", 16), new LinearLayout.LayoutParams(-1, 70)); return; }
            for (String record : records) {
                String[] values = decodeRecord(record); String titleText = values.length > 0 ? values[0] : "سجل";
                LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(12, 8, 12, 8); card.setBackground(bg(PALE, 18));
                TextView a = tv("📌 " + safe(titleText, "سجل"), 18); a.setTextColor(GREEN); card.addView(a);
                if (values.length > 3 && !values[3].isEmpty()) card.addView(tv("الحالة: " + values[3], 13));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 82); lp.setMargins(0, 8, 0, 0); list.addView(card, lp);
                card.setOnClickListener(v -> showRecordDetails(title, key, labels, record, refresh[0]));
            }
        };
        add.setOnClickListener(v -> showRecordForm(title, key, labels, null, refresh[0]));
        back.setOnClickListener(v -> showDashboard()); refresh[0].run();
    }

    private ArrayList<String> getRecords(String key) {
        return new ArrayList<>(prefs.getStringSet("module_" + key, new HashSet<>()));
    }

    private String[] decodeRecord(String record) {
        try {
            String[] e = record.split("\\|", -1); String[] v = new String[e.length];
            for (int i = 0; i < e.length; i++) v[i] = dec(e[i]); return v;
        } catch (Exception ex) { return new String[0]; }
    }

    private String encodeRecord(String[] values) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < values.length; i++) { if (i > 0) b.append("|"); b.append(enc(values[i])); }
        return b.toString();
    }

    private void saveRecord(String key, String oldRecord, String newRecord) {
        Set<String> current = new HashSet<>(prefs.getStringSet("module_" + key, new HashSet<>()));
        if (oldRecord != null) current.remove(oldRecord); current.add(newRecord);
        prefs.edit().putStringSet("module_" + key, current).apply();
    }

    private void removeRecord(String key, String record) {
        Set<String> current = new HashSet<>(prefs.getStringSet("module_" + key, new HashSet<>())); current.remove(record);
        prefs.edit().putStringSet("module_" + key, current).apply();
    }

    private void showRecordForm(String title, String key, String[] labels, String oldRecord, Runnable refresh) {
        String[] old = oldRecord == null ? new String[labels.length] : decodeRecord(oldRecord);
        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL); form.setPadding(20, 4, 20, 4);
        EditText[] inputs = new EditText[labels.length];
        for (int i = 0; i < labels.length; i++) {
            inputs[i] = new EditText(this); inputs[i].setHint(labels[i]);
            if (i < old.length && old[i] != null) inputs[i].setText(old[i]); inputs[i].setSingleLine(i != 1); form.addView(inputs[i]);
        }
        new AlertDialog.Builder(this).setTitle(oldRecord == null ? "➕ " + title : "✏️ تعديل السجل").setView(form)
                .setPositiveButton("حفظ", (d, w) -> {
                    String[] values = new String[labels.length];
                    for (int i = 0; i < labels.length; i++) values[i] = inputs[i].getText().toString().trim();
                    if (values.length > 0 && values[0].isEmpty()) values[0] = "سجل بدون اسم";
                    saveRecord(key, oldRecord, encodeRecord(values)); refresh.run();
                    Toast.makeText(this, "تم الحفظ بنجاح", Toast.LENGTH_SHORT).show();
                }).setNegativeButton("إلغاء", null).show();
    }

    private void showRecordDetails(String title, String key, String[] labels, String record, Runnable refresh) {
        String[] values = decodeRecord(record); StringBuilder message = new StringBuilder();
        for (int i = 0; i < labels.length; i++) { String value = i < values.length ? values[i] : ""; message.append(labels[i]).append(": ").append(safe(value, "غير محدد")).append("\n"); }
        new AlertDialog.Builder(this).setTitle("📋 " + (values.length > 0 ? values[0] : title)).setMessage(message.toString())
                .setPositiveButton("✏️ تعديل", (d, w) -> showRecordForm(title, key, labels, record, refresh))
                .setNegativeButton("🗑️ حذف", (d, w) -> new AlertDialog.Builder(this).setTitle("حذف السجل").setMessage("هل تريد حذف هذا السجل؟")
                        .setPositiveButton("حذف", (x, y) -> { removeRecord(key, record); refresh.run(); Toast.makeText(this, "تم حذف السجل", Toast.LENGTH_SHORT).show(); })
                        .setNegativeButton("إلغاء", null).show())
                .setNeutralButton("إغلاق", null).show();
    }

    private int moduleCount(String key) { return prefs.getStringSet("module_" + key, new HashSet<>()).size(); }

    private void showReports() {
        base(); TextView h = tv("📊 التقارير والإحصائيات", 24); h.setTextColor(Color.WHITE); h.setBackground(bg(GREEN, 24));
        root.addView(h, new LinearLayout.LayoutParams(-1, 72));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); ScrollView scroll = new ScrollView(this); scroll.addView(list);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        addReportCard(list, "🚨 البلاغات البيئية", moduleCount("complaints"));
        addReportCard(list, "👷 المهام الميدانية", moduleCount("tasks"));
        addReportCard(list, "🏭 المنشآت", moduleCount("facilities"));
        addReportCard(list, "📄 التراخيص", moduleCount("licenses"));
        addReportCard(list, "🗑️ سجلات النفايات", moduleCount("waste"));
        addReportCard(list, "📍 المواقع المحفوظة على الخريطة", savedMarkers.size());
        list.addView(tv("تُحفظ البيانات محليًا على الجهاز في هذه النسخة التجريبية.", 14));
        Button back = btn("↩ العودة إلى لوحة الإدارة"); root.addView(back, new LinearLayout.LayoutParams(-1, 58)); back.setOnClickListener(v -> showDashboard());
    }

    private void addReportCard(LinearLayout parent, String label, int count) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(18, 8, 18, 8); card.setBackground(bg(PALE, 18));
        TextView name = tv(label, 17); name.setTextColor(GREEN); TextView number = tv(String.valueOf(count), 25); number.setTextColor(GREEN);
        card.addView(name, new LinearLayout.LayoutParams(0, 70, 1)); card.addView(number, new LinearLayout.LayoutParams(80, 70));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 78); lp.setMargins(0, 8, 0, 0); parent.addView(card, lp);
    }

    private Button toolbarButton(String text) {
        Button b = btn(text);
        b.setPadding(4, 0, 4, 0);
        return b;
    }

    private void showMap() {
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE));
        base();
        addMode = false;

        TextView h = tv("🗺️ الخريطة البيئية", 22);
        h.setTextColor(GREEN);
        h.setBackground(bg(PALE, 20));
        root.addView(h, new LinearLayout.LayoutParams(-1, 62));

        LinearLayout layers = new LinearLayout(this);
        layers.setOrientation(LinearLayout.HORIZONTAL);
        Button roads = toolbarButton("🗺️ الطرق");
        Button satellite = toolbarButton("🛰️ الأقمار");
        Button terrain = toolbarButton("⛰️ التضاريس");
        layers.addView(roads, new LinearLayout.LayoutParams(0, 54, 1));
        layers.addView(satellite, new LinearLayout.LayoutParams(0, 54, 1));
        layers.addView(terrain, new LinearLayout.LayoutParams(0, 54, 1));
        root.addView(layers);

        LinearLayout actions1 = new LinearLayout(this);
        actions1.setOrientation(LinearLayout.HORIZONTAL);
        Button gps = toolbarButton("📍 موقعي");
        Button add = toolbarButton("➕ إضافة");
        Button search = toolbarButton("🔎 بحث");
        Button saved = toolbarButton("📌 المحفوظة");
        actions1.addView(gps, new LinearLayout.LayoutParams(0, 54, 1));
        actions1.addView(add, new LinearLayout.LayoutParams(0, 54, 1));
        actions1.addView(search, new LinearLayout.LayoutParams(0, 54, 1));
        actions1.addView(saved, new LinearLayout.LayoutParams(0, 54, 1));
        root.addView(actions1);

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.setBuiltInZoomControls(true);
        map.setMinZoomLevel(5.0);
        map.setMaxZoomLevel(18.0);
        map.getController().setZoom(7.0);
        map.getController().setCenter(new GeoPoint(34.8021, 38.9968));
        root.addView(map, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView status = tv("اختر نوع الخريطة، ثم استخدم GPS أو إضافة موقع أو البحث.", 12);
        root.addView(status, new LinearLayout.LayoutParams(-1, 48));
        Button back = btn("↩ العودة إلى لوحة الإدارة");
        root.addView(back, new LinearLayout.LayoutParams(-1, 58));
        back.setOnClickListener(v -> {
            addMode = false;
            if (map != null) map.onDetach();
            showDashboard();
        });

        loadSavedMarkers();
        setupLocation();
        installMapEvents();

        roads.setOnClickListener(v -> setLayer(TileSourceFactory.MAPNIK, "خريطة الطرق"));
        satellite.setOnClickListener(v -> setLayer(SATELLITE, "صور الأقمار الصناعية"));
        terrain.setOnClickListener(v -> setLayer(TileSourceFactory.OpenTopo, "الخريطة التضاريسية"));
        gps.setOnClickListener(v -> goToMyLocation());
        add.setOnClickListener(v -> {
            addMode = true;
            status.setText("➕ وضع الإضافة فعال: اضغط على المكان المطلوب أو اضغط مطولاً عليه.");
            Toast.makeText(this, "اضغط على الموقع المطلوب لإضافته", Toast.LENGTH_LONG).show();
        });
        search.setOnClickListener(v -> searchLocation());
        saved.setOnClickListener(v -> showSavedPlaces());
    }

    private void setLayer(org.osmdroid.tileprovider.tilesource.ITileSource source, String name) {
        map.setTileSource(source);
        map.invalidate();
        Toast.makeText(this, "تم اختيار " + name, Toast.LENGTH_SHORT).show();
    }

    private void installMapEvents() {
        MapEventsOverlay overlay = new MapEventsOverlay(new MapEventsReceiver() {
            @Override public boolean singleTapConfirmedHelper(GeoPoint p) {
                if (!addMode) return false;
                addMode = false;
                askPlaceDetails(p);
                return true;
            }
            @Override public boolean longPressHelper(GeoPoint p) {
                if (!addMode) return false;
                addMode = false;
                askPlaceDetails(p);
                return true;
            }
        });
        map.getOverlays().add(0, overlay);
    }

    private void searchLocation() {
        EditText input = new EditText(this);
        input.setHint("مثال: دمشق، حلب، حمص، منشأة...");
        input.setSingleLine(true);
        new AlertDialog.Builder(this).setTitle("🔎 البحث عن موقع").setView(input)
                .setPositiveButton("بحث", (d, w) -> {
                    String q = input.getText().toString().trim();
                    if (q.isEmpty()) return;
                    Toast.makeText(this, "جارٍ البحث...", Toast.LENGTH_SHORT).show();
                    searchExecutor.execute(() -> {
                        try {
                            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                            java.util.List<Address> results = geocoder.getFromLocationName(q, 5, 32.3, 35.6, 37.4, 42.5);
                            runOnUiThread(() -> {
                                if (results == null || results.isEmpty()) {
                                    Toast.makeText(this, "لم يتم العثور على الموقع", Toast.LENGTH_LONG).show();
                                    return;
                                }
                                Address a = results.get(0);
                                GeoPoint p = new GeoPoint(a.getLatitude(), a.getLongitude());
                                map.getController().animateTo(p);
                                map.getController().setZoom(13.0);
                                Toast.makeText(this, "تم الانتقال إلى: " + q, Toast.LENGTH_SHORT).show();
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> Toast.makeText(this, "تعذر البحث. تأكد من وجود الإنترنت.", Toast.LENGTH_LONG).show());
                        }
                    });
                }).setNegativeButton("إلغاء", null).show();
    }

    private void goToMyLocation() {
        if (myLocationOverlay != null && myLocationOverlay.getMyLocation() != null) {
            GeoPoint p = myLocationOverlay.getMyLocation();
            map.getController().animateTo(p);
            map.getController().setZoom(15.0);
        } else {
            requestLocationPermission();
            Toast.makeText(this, "جارٍ محاولة تحديد موقعك... فعّل GPS إذا لزم الأمر", Toast.LENGTH_LONG).show();
        }
    }

    private void askPlaceDetails(GeoPoint point) {
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(20, 4, 20, 4);

        EditText name = new EditText(this);
        name.setHint("اسم الموقع / المنشأة");
        name.setSingleLine(true);
        EditText type = new EditText(this);
        type.setHint("نوع الموقع: منشأة، مكب، شكوى، مراقبة...");
        type.setSingleLine(true);
        EditText status = new EditText(this);
        status.setHint("الحالة: سليم، يحتاج متابعة، خطر...");
        status.setSingleLine(true);
        EditText rating = new EditText(this);
        rating.setHint("التقييم من 1 إلى 5 نجوم");
        rating.setInputType(InputType.TYPE_CLASS_NUMBER);
        rating.setSingleLine(true);
        EditText notes = new EditText(this);
        notes.setHint("ملاحظات إضافية");
        notes.setMinLines(2);
        form.addView(name); form.addView(type); form.addView(status); form.addView(rating); form.addView(notes);

        new AlertDialog.Builder(this).setTitle("➕ إضافة موقع بيئي").setView(form)
                .setPositiveButton("حفظ", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) n = "موقع بيئي";
                    String ty = type.getText().toString().trim();
                    String st = status.getText().toString().trim();
                    int stars = 0;
                    try { stars = Math.max(0, Math.min(5, Integer.parseInt(rating.getText().toString().trim()))); } catch (Exception ignored) {}
                    String note = notes.getText().toString().trim();
                    saveMarker(n, ty, st, stars, note, point);
                }).setNegativeButton("إلغاء", null).show();
    }

    private void saveMarker(String name, String type, String status, int stars, String notes, GeoPoint point) {
        Marker marker = createMarker(name, type, status, stars, notes, point);
        map.getOverlays().add(marker);
        savedMarkers.add(marker);
        persistMarkers();
        map.getController().animateTo(point);
        map.invalidate();
        Toast.makeText(this, "تم حفظ الموقع بنجاح", Toast.LENGTH_SHORT).show();
    }

    private Marker createMarker(String name, String type, String status, int stars, String notes, GeoPoint point) {
        Marker marker = new Marker(map);
        marker.setPosition(point);
        marker.setTitle(name);
        marker.setSnippet(buildSnippet(type, status, stars, notes, point));
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        marker.setOnMarkerClickListener((m, mapView) -> {
            showMarkerDetails(m);
            return true;
        });
        return marker;
    }

    private String buildSnippet(String type, String status, int stars, String notes, GeoPoint p) {
        String starText = stars <= 0 ? "غير مصنف" : starsText(stars);
        return "النوع: " + safe(type, "غير محدد") + "\n" +
                "الحالة: " + safe(status, "غير محددة") + "\n" +
                "التقييم: " + starText + "\n" +
                "الملاحظات: " + safe(notes, "لا توجد") + "\n" +
                String.format(Locale.US, "الإحداثيات: %.6f, %.6f", p.getLatitude(), p.getLongitude());
    }

    private String starsText(int stars) { StringBuilder b = new StringBuilder(); for (int i = 0; i < stars; i++) b.append("★"); return b.toString(); }

    private String safe(String value, String fallback) { return value == null || value.trim().isEmpty() ? fallback : value; }

    private void showMarkerDetails(Marker marker) {
        new AlertDialog.Builder(this)
                .setTitle("📍 " + marker.getTitle())
                .setMessage(marker.getSnippet())
                .setPositiveButton("✏️ تعديل", (d, w) -> editMarker(marker))
                .setNegativeButton("🗑️ حذف", (d, w) -> deleteMarker(marker))
                .setNeutralButton("إغلاق", null).show();
    }

    private void editMarker(Marker marker) {
        PlaceData old = parseMarker(marker);
        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(20, 4, 20, 4);
        EditText name = field("اسم الموقع", old.name); 
        EditText type = field("النوع", old.type);
        EditText status = field("الحالة", old.status);
        EditText rating = field("التقييم 1-5", old.stars == 0 ? "" : String.valueOf(old.stars));
        rating.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText notes = field("الملاحظات", old.notes);
        form.addView(name); form.addView(type); form.addView(status); form.addView(rating); form.addView(notes);
        new AlertDialog.Builder(this).setTitle("✏️ تعديل الموقع").setView(form)
                .setPositiveButton("حفظ", (d, w) -> {
                    int stars = 0;
                    try { stars = Math.max(0, Math.min(5, Integer.parseInt(rating.getText().toString().trim()))); } catch (Exception ignored) {}
                    marker.setTitle(name.getText().toString().trim().isEmpty() ? "موقع بيئي" : name.getText().toString().trim());
                    marker.setSnippet(buildSnippet(type.getText().toString().trim(), status.getText().toString().trim(), stars, notes.getText().toString().trim(), marker.getPosition()));
                    persistMarkers();
                    map.invalidate();
                    Toast.makeText(this, "تم تعديل الموقع", Toast.LENGTH_SHORT).show();
                }).setNegativeButton("إلغاء", null).show();
    }

    private EditText field(String hint, String value) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setText(value == null ? "" : value); e.setSingleLine(false);
        return e;
    }

    private void deleteMarker(Marker marker) {
        new AlertDialog.Builder(this).setTitle("حذف الموقع")
                .setMessage("هل تريد حذف هذا الموقع نهائيًا من الجهاز؟")
                .setPositiveButton("حذف", (d, w) -> {
                    map.getOverlays().remove(marker);
                    savedMarkers.remove(marker);
                    persistMarkers();
                    map.invalidate();
                    Toast.makeText(this, "تم حذف الموقع", Toast.LENGTH_SHORT).show();
                }).setNegativeButton("إلغاء", null).show();
    }

    private static class PlaceData {
        String name = "موقع بيئي", type = "", status = "", notes = ""; int stars = 0;
    }

    private PlaceData parseMarker(Marker marker) {
        PlaceData d = new PlaceData();
        String s = marker.getSnippet();
        if (s == null) return d;
        String[] lines = s.split("\\n");
        for (String line : lines) {
            if (line.startsWith("النوع: ")) d.type = line.substring(7);
            else if (line.startsWith("الحالة: ")) d.status = line.substring(8);
            else if (line.startsWith("التقييم: ")) d.stars = line.substring(9).replace("★", "").trim().equals("غير مصنف") ? 0 : line.substring(9).trim().length();
            else if (line.startsWith("الملاحظات: ")) d.notes = line.substring(11);
        }
        d.name = marker.getTitle();
        return d;
    }

    private void persistMarkers() {
        Set<String> data = new HashSet<>();
        for (Marker m : savedMarkers) {
            PlaceData d = parseMarker(m);
            GeoPoint p = m.getPosition();
            data.add(enc(d.name) + "|" + enc(d.type) + "|" + enc(d.status) + "|" + d.stars + "|" + enc(d.notes) + "|" + p.getLatitude() + "|" + p.getLongitude());
        }
        prefs.edit().putStringSet("places", data).apply();
    }

    private String enc(String s) { return Base64.encodeToString((s == null ? "" : s).getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP); }
    private String dec(String s) { try { return new String(Base64.decode(s, Base64.DEFAULT), StandardCharsets.UTF_8); } catch (Exception e) { return s; } }

    private void loadSavedMarkers() {
        Set<String> data = prefs.getStringSet("places", new HashSet<>());
        for (String item : data) {
            try {
                String[] p = item.split("\\|", -1);
                if (p.length == 7) {
                    addLoadedMarker(dec(p[0]), dec(p[1]), dec(p[2]), Integer.parseInt(p[3]), dec(p[4]), new GeoPoint(Double.parseDouble(p[5]), Double.parseDouble(p[6])));
                } else if (p.length == 3) {
                    addLoadedMarker(p[0], "", "", 0, "", new GeoPoint(Double.parseDouble(p[1]), Double.parseDouble(p[2])));
                }
            } catch (Exception ignored) { }
        }
    }

    private void addLoadedMarker(String name, String type, String status, int stars, String notes, GeoPoint point) {
        Marker marker = createMarker(name, type, status, stars, notes, point);
        map.getOverlays().add(marker);
        savedMarkers.add(marker);
    }

    private void showSavedPlaces() {
        if (savedMarkers.isEmpty()) {
            Toast.makeText(this, "لا توجد مواقع محفوظة بعد", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[savedMarkers.size()];
        for (int i = 0; i < savedMarkers.size(); i++) names[i] = savedMarkers.get(i).getTitle();
        new AlertDialog.Builder(this).setTitle("📌 المواقع المحفوظة").setItems(names, (d, which) -> {
            Marker m = savedMarkers.get(which);
            map.getController().animateTo(m.getPosition());
            map.getController().setZoom(15.0);
            showMarkerDetails(m);
        }).setNegativeButton("إغلاق", null).show();
    }

    private void setupLocation() {
        myLocationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
        myLocationOverlay.enableMyLocation();
        map.getOverlays().add(myLocationOverlay);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            myLocationOverlay.enableFollowLocation();
        } else requestLocationPermission();
    }

    private void requestLocationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST && myLocationOverlay != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                myLocationOverlay.enableMyLocation(); myLocationOverlay.enableFollowLocation();
            } else Toast.makeText(this, "يمكن استخدام الخريطة بدون GPS، لكن موقعي يحتاج إذن الموقع.", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() { searchExecutor.shutdownNow(); if (map != null) map.onDetach(); super.onDestroy(); }
    @Override protected void onResume() { super.onResume(); if (map != null) map.onResume(); }
    @Override protected void onPause() { if (map != null) map.onPause(); super.onPause(); }
}
