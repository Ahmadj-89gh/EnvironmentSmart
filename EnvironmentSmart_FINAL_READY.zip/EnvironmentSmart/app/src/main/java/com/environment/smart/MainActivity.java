package com.environment.smart;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.MapTileIndex;
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider;
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 1001;
    private static final int GREEN = Color.rgb(11, 61, 46);
    private static final int GOLD = Color.rgb(190, 145, 45);
    private LinearLayout root, content;
    private MapView map;
    private MyLocationNewOverlay myLocationOverlay;
    private final ArrayList<Marker> savedMarkers = new ArrayList<>();
    private SharedPreferences prefs;
    private boolean addMode = false;
    private final ExecutorService searchExecutor = Executors.newSingleThreadExecutor();

    private static final OnlineTileSourceBase SATELLITE = new OnlineTileSourceBase(
            "ArcGIS World Imagery",
            1, 18, 256, ".jpg",
            new String[]{"https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/"},
            "Esri World Imagery") {
        @Override
        public String getTileURLString(final long pMapTileIndex) {
            return getBaseUrl()
                    + MapTileIndex.getZoom(pMapTileIndex) + "/"
                    + MapTileIndex.getY(pMapTileIndex) + "/"
                    + MapTileIndex.getX(pMapTileIndex) + mImageFilenameEnding;
        }
    };

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        prefs = getSharedPreferences("saved_places", MODE_PRIVATE);
        showLogin();
    }

    private TextView tv(String s, float z) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(z);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(24, 18, 24, 18);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(16);
        b.setAllCaps(false);
        return b;
    }

    private GradientDrawable bg(int c, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(c);
        g.setCornerRadius(r);
        return g;
    }

    private void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);
    }


    private void addBrandHeader(boolean compact) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(10, 8, 10, 8);
        header.setBackground(bg(Color.rgb(247, 250, 247), 22));

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.environment.smart.R.drawable.app_icon);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        int size = compact ? 62 : 82;
        header.addView(logo, new LinearLayout.LayoutParams(size, size));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);
        TextView ministry = tv("الجمهورية العربية السورية\nوزارة الإدارة المحلية والبيئة\nمديرية بيئة اللاذقية", compact ? 12 : 14);
        ministry.setTextColor(GREEN);
        ministry.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        ministry.setPadding(10, 0, 6, 0);
        texts.addView(ministry, new LinearLayout.LayoutParams(0, -2, 1));

        TextView appName = tv("🌿 البيئة الذكية", compact ? 16 : 19);
        appName.setTextColor(GREEN);
        appName.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        appName.setPadding(10, 0, 6, 0);
        texts.addView(appName, new LinearLayout.LayoutParams(-1, 34));
        header.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));

        root.addView(header, new LinearLayout.LayoutParams(-1, compact ? 92 : 126));
    }

    private void addCreditFooter() {
        TextView f = tv("تنفيذ الأستاذ أحمد جابر غصون", 13);
        f.setTextColor(GREEN);
        f.setTypeface(null, android.graphics.Typeface.BOLD);
        f.setPadding(8, 10, 8, 10);
        f.setBackground(bg(Color.rgb(247, 250, 247), 18));
        root.addView(f, new LinearLayout.LayoutParams(-1, 52));
    }

    private void addFullFooter() {
        TextView f = tv("الجمهورية العربية السورية  |  وزارة الإدارة المحلية والبيئة  |  مديرية بيئة اللاذقية\nتنفيذ الأستاذ أحمد جابر غصون", 12);
        f.setTextColor(GREEN);
        f.setPadding(8, 8, 8, 8);
        root.addView(f, new LinearLayout.LayoutParams(-1, 64));
    }

    private void showLogin() {
        base();
        addBrandHeader(false);
        Space spacer = new Space(this);
        root.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1));
        root.addView(tv("نظام رقمي لإدارة أعمال مديرية البيئة", 18));
        EditText u = new EditText(this);
        u.setHint("اسم المستخدم");
        EditText p = new EditText(this);
        p.setHint("كلمة المرور");
        p.setInputType(129);
        root.addView(u);
        root.addView(p);
        Button l = btn("دخول");
        root.addView(l, new LinearLayout.LayoutParams(-1, 60));
        root.addView(tv("نسخة أولية تجريبية", 13));
        addCreditFooter();
        l.setOnClickListener(v -> {
            boolean ok = (u.getText().toString().trim().equals("admin") && p.getText().toString().equals("admin123"))
                    || (u.getText().toString().trim().equals("أحمد") && p.getText().toString().equals("1234"));
            if (ok) showDashboard();
            else Toast.makeText(this, "بيانات الدخول التجريبية: admin / admin123", Toast.LENGTH_LONG).show();
        });
    }

    private void showDashboard() {
        base();
        addBrandHeader(false);
        TextView h = tv("لوحة الإدارة البيئية", 22);
        h.setTextColor(Color.WHITE);
        h.setBackground(bg(GREEN, 22));
        root.addView(h, new LinearLayout.LayoutParams(-1, 72));
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        addCard("🗺️ الخريطة البيئية", "خريطة حقيقية تفاعلية + GPS + حفظ المواقع", v -> showMap());
        addCard("🚨 البلاغات البيئية", "إدارة الشكاوى والبلاغات", v -> message("البلاغات", "سيتم بناء هذه الوحدة في المرحلة التالية."));
        addCard("👷 المهام الميدانية", "توزيع ومتابعة أعمال فرق التفتيش", v -> message("المهام", "سيتم بناء هذه الوحدة في المرحلة التالية."));
        addCard("🏭 المنشآت", "الملفات البيئية للمنشآت", v -> message("المنشآت", "سيتم بناء هذه الوحدة في المرحلة التالية."));
        addCard("📄 التراخيص", "التراخيص والموافقات البيئية", v -> message("التراخيص", "سيتم بناء هذه الوحدة في المرحلة التالية."));
        addCard("🗑️ النفايات", "متابعة المكبات والجمع والمعالجة", v -> message("النفايات", "سيتم بناء هذه الوحدة في المرحلة التالية."));
        addCard("📊 التقارير", "الإحصائيات ومؤشرات الأداء", v -> message("التقارير", "سيتم بناء هذه الوحدة في المرحلة التالية."));
        Button out = btn("تسجيل الخروج");
        root.addView(out, new LinearLayout.LayoutParams(-1, 60));
        out.setOnClickListener(v -> showLogin());
        addCreditFooter();
    }

    private void addCard(String a, String b, View.OnClickListener l) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(12, 8, 12, 8);
        box.setBackground(bg(Color.rgb(238, 247, 240), 22));
        TextView x = tv(a, 19);
        x.setTextColor(GREEN);
        box.addView(x);
        box.addView(tv(b, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 105);
        lp.setMargins(0, 10, 0, 0);
        content.addView(box, lp);
        box.setOnClickListener(l);
    }

    private void message(String t, String m) {
        new AlertDialog.Builder(this).setTitle(t).setMessage(m).setPositiveButton("حسناً", null).show();
    }

    private void showMap() {
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE));
        base();
        addMode = false;

        addBrandHeader(true);
        TextView h = tv("🗺️ الخريطة البيئية", 21);
        h.setTextColor(GREEN);
        root.addView(h, new LinearLayout.LayoutParams(-1, 58));

        LinearLayout layers = new LinearLayout(this);
        layers.setOrientation(LinearLayout.HORIZONTAL);
        Button roads = btn("🗺️ طرق");
        Button satellite = btn("🛰️ أقمار");
        Button terrain = btn("⛰️ تضاريس");
        layers.addView(roads, new LinearLayout.LayoutParams(0, 58, 1));
        layers.addView(satellite, new LinearLayout.LayoutParams(0, 58, 1));
        layers.addView(terrain, new LinearLayout.LayoutParams(0, 58, 1));
        root.addView(layers);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button gps = btn("📍 موقعي");
        Button add = btn("➕ إضافة موقع");
        Button search = btn("🔎 بحث");
        actions.addView(gps, new LinearLayout.LayoutParams(0, 58, 1));
        actions.addView(add, new LinearLayout.LayoutParams(0, 58, 1));
        actions.addView(search, new LinearLayout.LayoutParams(0, 58, 1));
        root.addView(actions);

        map = new MapView(this);
        map.setTileSource(TileSourceFactory.MAPNIK);
        map.setMultiTouchControls(true);
        map.setBuiltInZoomControls(true);
        map.setMinZoomLevel(5.0);
        map.setMaxZoomLevel(18.0);
        map.getController().setZoom(7.0);
        map.getController().setCenter(new GeoPoint(34.8021, 38.9968));
        root.addView(map, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView hint = tv("🗺️ طرق  |  🛰️ أقمار صناعية  |  ⛰️ تضاريس  |  📍 GPS  |  ➕ إضافة موقع  |  🔎 بحث", 12);
        root.addView(hint, new LinearLayout.LayoutParams(-1, 55));

        Button back = btn("العودة إلى لوحة الإدارة");
        root.addView(back, new LinearLayout.LayoutParams(-1, 60));
        back.setOnClickListener(v -> {
            addMode = false;
            if (map != null) map.onDetach();
            showDashboard();
        });
        addCreditFooter();

        loadSavedMarkers();
        setupLocation();
        installMapEvents();

        roads.setOnClickListener(v -> {
            map.setTileSource(TileSourceFactory.MAPNIK);
            map.invalidate();
            Toast.makeText(this, "تم اختيار خريطة الطرق", Toast.LENGTH_SHORT).show();
        });

        satellite.setOnClickListener(v -> {
            map.setTileSource(SATELLITE);
            map.invalidate();
            Toast.makeText(this, "تم اختيار صور الأقمار الصناعية", Toast.LENGTH_SHORT).show();
        });

        terrain.setOnClickListener(v -> {
            map.setTileSource(TileSourceFactory.OpenTopo);
            map.invalidate();
            Toast.makeText(this, "تم اختيار الخريطة التضاريسية", Toast.LENGTH_SHORT).show();
        });

        gps.setOnClickListener(v -> {
            if (myLocationOverlay != null && myLocationOverlay.getMyLocation() != null) {
                map.getController().animateTo(myLocationOverlay.getMyLocation());
                map.getController().setZoom(15.0);
            } else {
                requestLocationPermission();
                Toast.makeText(this, "جارٍ محاولة تحديد موقعك...", Toast.LENGTH_SHORT).show();
            }
        });

        add.setOnClickListener(v -> {
            addMode = true;
            Toast.makeText(this, "الآن اضغط مطولاً على المكان المطلوب في الخريطة", Toast.LENGTH_LONG).show();
        });

        search.setOnClickListener(v -> searchLocation());
    }

    private void installMapEvents() {
        org.osmdroid.views.overlay.MapEventsOverlay eventsOverlay =
                new org.osmdroid.views.overlay.MapEventsOverlay(
                        new org.osmdroid.events.MapEventsReceiver() {
                            @Override
                            public boolean singleTapConfirmedHelper(GeoPoint p) {
                                return false;
                            }

                            @Override
                            public boolean longPressHelper(GeoPoint p) {
                                if (!addMode) return false;
                                addMode = false;
                                askPlaceName(p);
                                return true;
                            }
                        });
        map.getOverlays().add(eventsOverlay);
    }

    private void searchLocation() {
        EditText input = new EditText(this);
        input.setHint("مثال: دمشق أو حمص أو حلب");
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("البحث عن موقع")
                .setView(input)
                .setPositiveButton("بحث", (d, w) -> {
                    String q = input.getText().toString().trim();
                    if (q.isEmpty()) return;
                    Toast.makeText(this, "جارٍ البحث...", Toast.LENGTH_SHORT).show();
                    searchExecutor.execute(() -> {
                        try {
                            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
                            java.util.List<Address> results = geocoder.getFromLocationName(q, 5, 32.3, 35.6, 37.4, 42.5);
                            runOnUiThread(() -> {
                                if (results == null || results.isEmpty()) {
                                    Toast.makeText(this, "لم يتم العثور على الموقع", Toast.LENGTH_LONG).show();
                                    return;
                                }
                                Address a = results.get(0);
                                GeoPoint p = new GeoPoint(a.getLatitude(), a.getLongitude());
                                map.getController().animateTo(p);
                                map.getController().setZoom(13.0);
                                Toast.makeText(this, "تم الانتقال إلى: " + q, Toast.LENGTH_SHORT).show();
                            });
                        } catch (Exception e) {
                            runOnUiThread(() -> Toast.makeText(this, "تعذر البحث. تأكد من وجود الإنترنت.", Toast.LENGTH_LONG).show());
                        }
                    });
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void choosePlaceOnMap() {
        addMode = true;
        Toast.makeText(this, "الآن اضغط مطولاً على المكان المطلوب في الخريطة", Toast.LENGTH_LONG).show();
    }

    private void askPlaceName(GeoPoint point) {
        EditText input = new EditText(this);
        input.setHint("اسم الموقع / المنشأة");
        input.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("حفظ موقع جديد")
                .setView(input)
                .setPositiveButton("حفظ", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) name = "موقع بيئي";
                    saveMarker(name, point);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void saveMarker(String name, GeoPoint point) {
        Marker marker = new Marker(map);
        marker.setPosition(point);
        marker.setTitle(name);
        marker.setSnippet(String.format(java.util.Locale.US, "%.6f, %.6f", point.getLatitude(), point.getLongitude()));
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        marker.setOnMarkerClickListener((m, mapView) -> {
            new AlertDialog.Builder(this)
                    .setTitle(m.getTitle())
                    .setMessage("الإحداثيات: " + m.getSnippet())
                    .setPositiveButton("تعديل الاسم", (d, w) -> editMarker(m))
                    .setNegativeButton("حذف", (d, w) -> {
                        map.getOverlays().remove(m);
                        removeSavedMarker(m.getTitle(), m.getPosition());
                        map.invalidate();
                    })
                    .setNeutralButton("إغلاق", null)
                    .show();
            return true;
        });
        map.getOverlays().add(marker);
        savedMarkers.add(marker);
        persistMarkers();
        map.getController().animateTo(point);
        map.invalidate();
        Toast.makeText(this, "تم حفظ الموقع", Toast.LENGTH_SHORT).show();
    }

    private void editMarker(Marker marker) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setText(marker.getTitle());
        new AlertDialog.Builder(this)
                .setTitle("تعديل الموقع")
                .setView(input)
                .setPositiveButton("حفظ", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (!name.isEmpty()) marker.setTitle(name);
                    persistMarkers();
                    map.invalidate();
                    Toast.makeText(this, "تم تعديل الموقع", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void persistMarkers() {
        Set<String> data = new HashSet<>();
        for (Marker m : savedMarkers) {
            GeoPoint p = m.getPosition();
            data.add(m.getTitle() + "|" + p.getLatitude() + "|" + p.getLongitude());
        }
        prefs.edit().putStringSet("places", data).apply();
    }

    private void loadSavedMarkers() {
        Set<String> data = prefs.getStringSet("places", new HashSet<>());
        for (String item : data) {
            String[] parts = item.split("\\|", -1);
            if (parts.length != 3) continue;
            try {
                saveMarkerSilently(parts[0], new GeoPoint(Double.parseDouble(parts[1]), Double.parseDouble(parts[2])));
            } catch (Exception ignored) { }
        }
    }

    private void saveMarkerSilently(String name, GeoPoint point) {
        Marker marker = new Marker(map);
        marker.setPosition(point);
        marker.setTitle(name);
        marker.setSnippet(String.format(java.util.Locale.US, "%.6f, %.6f", point.getLatitude(), point.getLongitude()));
        marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
        marker.setOnMarkerClickListener((m, mapView) -> {
            new AlertDialog.Builder(this)
                    .setTitle(m.getTitle())
                    .setMessage("الإحداثيات: " + m.getSnippet())
                    .setPositiveButton("تعديل الاسم", (d, w) -> editMarker(m))
                    .setNegativeButton("حذف", (d, w) -> {
                        map.getOverlays().remove(m);
                        savedMarkers.remove(m);
                        persistMarkers();
                        map.invalidate();
                    })
                    .setNeutralButton("إغلاق", null)
                    .show();
            return true;
        });
        map.getOverlays().add(marker);
        savedMarkers.add(marker);
    }

    private void removeSavedMarker(String title, GeoPoint position) {
        savedMarkers.removeIf(m -> m.getTitle().equals(title)
                && Math.abs(m.getPosition().getLatitude() - position.getLatitude()) < 0.000001
                && Math.abs(m.getPosition().getLongitude() - position.getLongitude()) < 0.000001);
        persistMarkers();
    }

    private void setupLocation() {
        myLocationOverlay = new MyLocationNewOverlay(new GpsMyLocationProvider(this), map);
        myLocationOverlay.enableMyLocation();
        map.getOverlays().add(myLocationOverlay);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            myLocationOverlay.enableFollowLocation();
        } else {
            requestLocationPermission();
        }
    }

    private void requestLocationPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION},
                    LOCATION_REQUEST);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST && myLocationOverlay != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                myLocationOverlay.enableMyLocation();
                myLocationOverlay.enableFollowLocation();
            } else {
                Toast.makeText(this, "يمكن استخدام الخريطة بدون GPS، لكن تحديد موقعي يحتاج إذن الموقع.", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        searchExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (map != null) map.onResume();
    }

    @Override
    protected void onPause() {
        if (map != null) map.onPause();
        super.onPause();
    }
}
